package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.MainViewModel
import com.example.ui.screens.EditorScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProxyBoardScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.*
import kotlinx.coroutines.flow.collectLatest

sealed class Screen(val route: String, val title: String, val selectedIcon: ImageVector, val unselectedIcon: ImageVector) {
    object Home : Screen("home", "Home", Icons.Filled.Shield, Icons.Outlined.Shield)
    object ProxyBoard : Screen("proxy_board", "Proxies", Icons.Filled.Storage, Icons.Outlined.Storage)
    object Editor : Screen("editor?profileId={profileId}", "Create", Icons.Filled.AddCircle, Icons.Outlined.AddCircleOutline) {
        fun createRoute(profileId: String? = null): String {
            return if (profileId != null) "editor?profileId=$profileId" else "editor"
        }
    }
    object Settings : Screen("settings", "Settings", Icons.Filled.Settings, Icons.Outlined.Settings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                SalahVpnApp()
            }
        }
    }
}

@Composable
fun SalahVpnApp() {
    val navController = rememberNavController()
    val viewModel: MainViewModel = viewModel()
    val snackbarHostState = remember { SnackbarHostState() }

    // Toast & snackbar event listener
    LaunchedEffect(Unit) {
        viewModel.toastMessage.collectLatest { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val navigationItems = listOf(
        Screen.Home,
        Screen.ProxyBoard,
        Screen.Editor,
        Screen.Settings
    )

    // Hide bottom bar only if in editor with a specific profile
    val showBottomBar = true

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyDarkBackground),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = NavySurface,
                    contentColor = SkyBluePrimary,
                    tonalElevation = 8.dp,
                    modifier = Modifier
                        .navigationBarsPadding()
                        .testTag("main_bottom_nav_bar")
                ) {
                    navigationItems.forEach { screen ->
                        val isSelected = when (screen) {
                            Screen.Editor -> currentRoute?.startsWith("editor") == true
                            else -> currentRoute == screen.route
                        }

                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                val target = if (screen == Screen.Editor) Screen.Editor.createRoute() else screen.route
                                navController.navigate(target) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) screen.selectedIcon else screen.unselectedIcon,
                                    contentDescription = screen.title
                                )
                            },
                            label = {
                                Text(
                                    text = screen.title,
                                    fontSize = 11.sp
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = NavyDarkBackground,
                                selectedTextColor = SkyBluePrimary,
                                indicatorColor = SkyBluePrimary,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            ),
                            modifier = Modifier.testTag("nav_item_${screen.title.lowercase()}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    viewModel = viewModel,
                    onNavigateToProxyBoard = {
                        navController.navigate(Screen.ProxyBoard.route)
                    },
                    onNavigateToEditor = { profileId ->
                        navController.navigate(Screen.Editor.createRoute(profileId))
                    }
                )
            }

            composable(Screen.ProxyBoard.route) {
                ProxyBoardScreen(
                    viewModel = viewModel,
                    onNavigateToEditor = { profileId ->
                        navController.navigate(Screen.Editor.createRoute(profileId))
                    }
                )
            }

            composable(
                route = Screen.Editor.route,
                arguments = listOf(
                    navArgument("profileId") {
                        type = NavType.StringType
                        nullable = true
                        defaultValue = null
                    }
                )
            ) { backStackEntry ->
                val profileId = backStackEntry.arguments?.getString("profileId")
                EditorScreen(
                    profileId = profileId,
                    viewModel = viewModel,
                    onNavigateBack = {
                        navController.popBackStack()
                    }
                )
            }

            composable(Screen.Settings.route) {
                SettingsScreen(viewModel = viewModel)
            }
        }
    }
}
