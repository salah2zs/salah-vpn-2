package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [ProfileEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun profileDao(): ProfileDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "salah_vpn.db"
                )
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Pre-populate with initial example profile demonstrating Proxy + Payload architecture
                        CoroutineScope(Dispatchers.IO).launch {
                            val dao = getDatabase(context).profileDao()
                            val demoProfile = ProfileEntity(
                                id = "demo-iq-proxy-payload",
                                name = "Iraq VIP · Proxy + Payload",
                                protocol = "VLESS",
                                server = "104.21.23.45",
                                port = 443,
                                authKey = "c8942745-f09d-4361-b4f6-7b4382585244",
                                flow = "",
                                alterId = 0,
                                cipher = "chacha20-poly1305",
                                transport = "WS",
                                security = "TLS",
                                sni = "speedtest.net",
                                alpn = "h2,http/1.1",
                                allowInsecure = false,
                                realityPublicKey = "",
                                realityShortId = "",
                                path = "/salah-vpn",
                                headerHost = "speedtest.net",
                                serviceName = "",
                                routeMode = "PROXY_PAYLOAD",
                                proxyHost = "185.199.108.153",
                                proxyPort = 8080,
                                payload = "CONNECT [host_port] HTTP/1.1[crlf]Host: [host][crlf]X-Online-Host: [host][crlf]Connection: Keep-Alive[crlf][crlf]",
                                isFavorite = true,
                                latencyMs = null,
                                lastPingStatus = null,
                                createdAt = System.currentTimeMillis()
                            )
                            dao.insertOrUpdate(demoProfile)
                        }
                    }
                })
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
