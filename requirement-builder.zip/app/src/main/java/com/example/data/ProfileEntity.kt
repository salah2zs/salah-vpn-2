package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.*

@Entity(tableName = "vpn_profiles")
data class ProfileEntity(
    @PrimaryKey val id: String,
    val name: String,
    val protocol: String,
    val server: String,
    val port: Int,
    val authKey: String,
    val flow: String,
    val alterId: Int,
    val cipher: String,
    val transport: String,
    val security: String,
    val sni: String,
    val alpn: String,
    val allowInsecure: Boolean,
    val realityPublicKey: String,
    val realityShortId: String,
    val path: String,
    val headerHost: String,
    val serviceName: String,
    val routeMode: String,
    val proxyHost: String,
    val proxyPort: Int,
    val payload: String,
    val isFavorite: Boolean,
    val latencyMs: Long?,
    val lastPingStatus: String?,
    val createdAt: Long
) {
    fun toDomain(): VpnProfile {
        return VpnProfile(
            id = id,
            name = name,
            protocol = try { Protocol.valueOf(protocol) } catch (_: Exception) { Protocol.VLESS },
            server = server,
            port = port,
            authKey = authKey,
            flow = flow,
            alterId = alterId,
            cipher = cipher,
            transport = try { Transport.valueOf(transport) } catch (_: Exception) { Transport.WS },
            security = try { Security.valueOf(security) } catch (_: Exception) { Security.TLS },
            sni = sni,
            alpn = alpn,
            allowInsecure = allowInsecure,
            realityPublicKey = realityPublicKey,
            realityShortId = realityShortId,
            path = path,
            headerHost = headerHost,
            serviceName = serviceName,
            routeMode = try { RouteMode.valueOf(routeMode) } catch (_: Exception) { RouteMode.DIRECT },
            proxyHost = proxyHost,
            proxyPort = proxyPort,
            payload = payload,
            isFavorite = isFavorite,
            latencyMs = latencyMs,
            lastPingStatus = lastPingStatus,
            createdAt = createdAt
        )
    }

    companion object {
        fun fromDomain(p: VpnProfile): ProfileEntity {
            return ProfileEntity(
                id = p.id,
                name = p.name,
                protocol = p.protocol.name,
                server = p.server,
                port = p.port,
                authKey = p.authKey,
                flow = p.flow,
                alterId = p.alterId,
                cipher = p.cipher,
                transport = p.transport.name,
                security = p.security.name,
                sni = p.sni,
                alpn = p.alpn,
                allowInsecure = p.allowInsecure,
                realityPublicKey = p.realityPublicKey,
                realityShortId = p.realityShortId,
                path = p.path,
                headerHost = p.headerHost,
                serviceName = p.serviceName,
                routeMode = p.routeMode.name,
                proxyHost = p.proxyHost,
                proxyPort = p.proxyPort,
                payload = p.payload,
                isFavorite = p.isFavorite,
                latencyMs = p.latencyMs,
                lastPingStatus = p.lastPingStatus,
                createdAt = p.createdAt
            )
        }
    }
}
