package com.example.data

import com.example.model.VpnProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class ProfileRepository(private val dao: ProfileDao) {

    val allProfiles: Flow<List<VpnProfile>> = dao.getAllProfiles().map { entities ->
        entities.map { it.toDomain() }
    }

    suspend fun getProfile(id: String): VpnProfile? {
        return dao.getProfileById(id)?.toDomain()
    }

    suspend fun saveProfile(profile: VpnProfile) {
        dao.insertOrUpdate(ProfileEntity.fromDomain(profile))
    }

    suspend fun saveAll(profiles: List<VpnProfile>) {
        dao.insertAll(profiles.map { ProfileEntity.fromDomain(it) })
    }

    suspend fun deleteProfile(id: String) {
        dao.deleteById(id)
    }

    suspend fun toggleFavorite(id: String, currentStatus: Boolean) {
        dao.setFavorite(id, !currentStatus)
    }

    suspend fun updateLatency(id: String, latencyMs: Long?, status: String?) {
        dao.updateLatency(id, latencyMs, status)
    }
}
