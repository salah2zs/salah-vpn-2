package com.example.engine

import com.example.model.Protocol
import com.example.model.RouteMode
import com.example.model.Security
import com.example.model.Transport
import com.example.model.VpnProfile
import org.json.JSONArray
import org.json.JSONObject

object ConfigGenerator {

    /**
     * Builds the Outbound JSONObject adhering strictly to sing-box / V2Ray spec
     * as described in Section 5 and 7.1.
     */
    fun buildOutbound(profile: VpnProfile, localForwarderPort: Int? = null): JSONObject {
        val outbound = JSONObject()
        val isUsingProxy = profile.routeMode == RouteMode.PROXY_PAYLOAD && profile.hasValidProxy() && localForwarderPort != null

        val serverAddress = if (isUsingProxy) "127.0.0.1" else profile.server
        val serverPort = if (isUsingProxy) localForwarderPort!! else profile.port

        when (profile.protocol) {
            Protocol.VLESS -> {
                outbound.put("type", "vless")
                outbound.put("tag", "proxy")
                outbound.put("server", serverAddress)
                outbound.put("server_port", serverPort)
                outbound.put("uuid", profile.authKey)
                if (profile.flow.isNotEmpty()) {
                    outbound.put("flow", profile.flow)
                }
            }
            Protocol.VMESS -> {
                outbound.put("type", "vmess")
                outbound.put("tag", "proxy")
                outbound.put("server", serverAddress)
                outbound.put("server_port", serverPort)
                outbound.put("uuid", profile.authKey)
                outbound.put("security", profile.cipher)
                outbound.put("alter_id", profile.alterId)
            }
            Protocol.TROJAN -> {
                outbound.put("type", "trojan")
                outbound.put("tag", "proxy")
                outbound.put("server", serverAddress)
                outbound.put("server_port", serverPort)
                outbound.put("password", profile.authKey)
            }
            Protocol.SHADOWSOCKS -> {
                outbound.put("type", "shadowsocks")
                outbound.put("tag", "proxy")
                outbound.put("server", serverAddress)
                outbound.put("server_port", serverPort)
                outbound.put("method", profile.cipher)
                outbound.put("password", profile.authKey)
            }
            Protocol.HYSTERIA2 -> {
                outbound.put("type", "hysteria2")
                outbound.put("tag", "proxy")
                outbound.put("server", profile.server)
                outbound.put("server_port", profile.port)
                outbound.put("password", profile.authKey)
            }
        }

        // Security / TLS configuration
        if (profile.protocol != Protocol.SHADOWSOCKS) {
            when (profile.security) {
                Security.TLS -> {
                    val tlsObj = JSONObject()
                    tlsObj.put("enabled", true)
                    tlsObj.put("server_name", profile.sni.ifEmpty { profile.server })
                    if (profile.alpn.isNotEmpty()) {
                        tlsObj.put("alpn", JSONArray(profile.alpn.split(",")))
                    }
                    if (profile.allowInsecure) {
                        tlsObj.put("insecure", true)
                    }
                    outbound.put("tls", tlsObj)
                }
                Security.REALITY -> {
                    val tlsObj = JSONObject()
                    tlsObj.put("enabled", true)
                    tlsObj.put("server_name", profile.sni.ifEmpty { profile.server })
                    val realityObj = JSONObject()
                    realityObj.put("enabled", true)
                    realityObj.put("public_key", profile.realityPublicKey)
                    realityObj.put("short_id", profile.realityShortId)
                    tlsObj.put("reality", realityObj)
                    outbound.put("tls", tlsObj)
                }
                Security.NONE -> {
                    // No TLS block
                }
            }
        }

        // Transport configuration
        if (profile.protocol != Protocol.HYSTERIA2) {
            when (profile.transport) {
                Transport.WS -> {
                    val transportObj = JSONObject()
                    transportObj.put("type", "ws")
                    transportObj.put("path", profile.path.ifEmpty { "/" })
                    val headersObj = JSONObject()
                    headersObj.put("Host", profile.headerHost.ifEmpty { profile.server })
                    transportObj.put("headers", headersObj)
                    outbound.put("transport", transportObj)
                }
                Transport.GRPC -> {
                    val transportObj = JSONObject()
                    transportObj.put("type", "grpc")
                    transportObj.put("service_name", profile.serviceName.ifEmpty { "default" })
                    outbound.put("transport", transportObj)
                }
                Transport.HTTP_UPGRADE -> {
                    val transportObj = JSONObject()
                    transportObj.put("type", "httpupgrade")
                    transportObj.put("path", profile.path.ifEmpty { "/" })
                    val headersObj = JSONObject()
                    headersObj.put("Host", profile.headerHost.ifEmpty { profile.server })
                    transportObj.put("headers", headersObj)
                    outbound.put("transport", transportObj)
                }
                Transport.TCP -> {
                    // Standard TCP
                }
            }
        }

        return outbound
    }

    /**
     * Complete sing-box config including inbounds (TUN), outbounds, route, and dns.
     */
    fun buildFullSingBoxConfig(profile: VpnProfile, localForwarderPort: Int? = null, dnsServer: String = "8.8.8.8"): JSONObject {
        val root = JSONObject()

        // Inbound: TUN
        val inbounds = JSONArray()
        val tun = JSONObject()
        tun.put("type", "tun")
        tun.put("tag", "tun-in")
        tun.put("address", JSONArray(listOf("172.19.0.1/30")))
        tun.put("auto_route", true)
        tun.put("stack", "system")
        tun.put("sniff", true)
        inbounds.put(tun)
        root.put("inbounds", inbounds)

        // Outbounds
        val outbounds = JSONArray()
        outbounds.put(buildOutbound(profile, localForwarderPort))

        val direct = JSONObject()
        direct.put("type", "direct")
        direct.put("tag", "direct")
        outbounds.put(direct)

        val block = JSONObject()
        block.put("type", "block")
        block.put("tag", "block")
        outbounds.put(block)

        root.put("outbounds", outbounds)

        // DNS
        val dns = JSONObject()
        val servers = JSONArray()
        val dnsServerObj = JSONObject()
        dnsServerObj.put("tag", "dns-remote")
        dnsServerObj.put("address", dnsServer)
        dnsServerObj.put("detour", "proxy")
        servers.put(dnsServerObj)
        dns.put("servers", servers)
        root.put("dns", dns)

        return root
    }
}
