package com.example.engine

import android.net.Uri
import android.util.Base64
import com.example.model.*
import org.json.JSONObject
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

object ConfigParser {

    private const val SZ_KEY = "SalahVpnIraqiDevKey32BytesLength" // 32 bytes AES-256 key

    fun parseUri(uriString: String): VpnProfile? {
        val trimmed = uriString.trim()
        return try {
            when {
                trimmed.startsWith("vless://", ignoreCase = true) -> parseVless(trimmed)
                trimmed.startsWith("vmess://", ignoreCase = true) -> parseVmess(trimmed)
                trimmed.startsWith("trojan://", ignoreCase = true) -> parseTrojan(trimmed)
                trimmed.startsWith("ss://", ignoreCase = true) -> parseShadowsocks(trimmed)
                trimmed.startsWith("hy2://", ignoreCase = true) || trimmed.startsWith("hysteria2://", ignoreCase = true) -> parseHysteria2(trimmed)
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun parseVless(uriString: String): VpnProfile {
        val uri = Uri.parse(uriString)
        val authKey = uri.userInfo ?: ""
        val server = uri.host ?: "127.0.0.1"
        val port = if (uri.port > 0) uri.port else 443
        val name = URLDecoder.decode(uri.fragment ?: "VLESS Server", "UTF-8")

        val type = uri.getQueryParameter("type") ?: "ws"
        val security = uri.getQueryParameter("security") ?: "tls"
        val sni = uri.getQueryParameter("sni") ?: server
        val host = uri.getQueryParameter("host") ?: sni
        val path = uri.getQueryParameter("path") ?: "/"
        val flow = uri.getQueryParameter("flow") ?: ""

        val transport = when (type.lowercase()) {
            "ws" -> Transport.WS
            "grpc" -> Transport.GRPC
            "httpupgrade" -> Transport.HTTP_UPGRADE
            else -> Transport.TCP
        }

        val sec = when (security.lowercase()) {
            "tls" -> Security.TLS
            "reality" -> Security.REALITY
            else -> Security.NONE
        }

        return VpnProfile(
            name = name,
            protocol = Protocol.VLESS,
            server = server,
            port = port,
            authKey = authKey,
            transport = transport,
            security = sec,
            sni = sni,
            headerHost = host,
            path = path,
            flow = flow,
            routeMode = RouteMode.DIRECT
        )
    }

    private fun parseVmess(uriString: String): VpnProfile {
        val base64Data = uriString.removePrefix("vmess://").trim()
        val jsonStr = String(Base64.decode(base64Data, Base64.DEFAULT), StandardCharsets.UTF_8)
        val json = JSONObject(jsonStr)

        val name = json.optString("ps", "VMess Server")
        val server = json.optString("add", "127.0.0.1")
        val port = json.optInt("port", 443)
        val authKey = json.optString("id", "")
        val alterId = json.optInt("aid", 0)
        val net = json.optString("net", "ws")
        val type = json.optString("type", "none")
        val host = json.optString("host", server)
        val path = json.optString("path", "/")
        val tls = json.optString("tls", "")
        val sni = json.optString("sni", host)

        val transport = if (net.equals("ws", ignoreCase = true)) Transport.WS else Transport.TCP
        val sec = if (tls.equals("tls", ignoreCase = true)) Security.TLS else Security.NONE

        return VpnProfile(
            name = name,
            protocol = Protocol.VMESS,
            server = server,
            port = port,
            authKey = authKey,
            alterId = alterId,
            transport = transport,
            security = sec,
            sni = sni,
            headerHost = host,
            path = path,
            routeMode = RouteMode.DIRECT
        )
    }

    private fun parseTrojan(uriString: String): VpnProfile {
        val uri = Uri.parse(uriString)
        val password = uri.userInfo ?: ""
        val server = uri.host ?: "127.0.0.1"
        val port = if (uri.port > 0) uri.port else 443
        val name = URLDecoder.decode(uri.fragment ?: "Trojan Server", "UTF-8")
        val type = uri.getQueryParameter("type") ?: "tcp"
        val sni = uri.getQueryParameter("sni") ?: server
        val host = uri.getQueryParameter("host") ?: sni
        val path = uri.getQueryParameter("path") ?: "/"

        val transport = if (type.equals("ws", ignoreCase = true)) Transport.WS else Transport.TCP

        return VpnProfile(
            name = name,
            protocol = Protocol.TROJAN,
            server = server,
            port = port,
            authKey = password,
            transport = transport,
            security = Security.TLS,
            sni = sni,
            headerHost = host,
            path = path,
            routeMode = RouteMode.DIRECT
        )
    }

    private fun parseShadowsocks(uriString: String): VpnProfile {
        val uri = Uri.parse(uriString)
        val name = URLDecoder.decode(uri.fragment ?: "Shadowsocks", "UTF-8")
        var userInfo = uri.userInfo ?: ""
        if (!userInfo.contains(":")) {
            // Might be base64 encoded userInfo
            try {
                userInfo = String(Base64.decode(userInfo, Base64.DEFAULT), StandardCharsets.UTF_8)
            } catch (_: Exception) {}
        }
        val parts = userInfo.split(":", limit = 2)
        val cipher = if (parts.isNotEmpty()) parts[0] else "chacha20-poly1305"
        val password = if (parts.size > 1) parts[1] else ""

        return VpnProfile(
            name = name,
            protocol = Protocol.SHADOWSOCKS,
            server = uri.host ?: "127.0.0.1",
            port = if (uri.port > 0) uri.port else 8388,
            cipher = cipher,
            authKey = password,
            security = Security.NONE,
            transport = Transport.TCP,
            routeMode = RouteMode.DIRECT
        )
    }

    private fun parseHysteria2(uriString: String): VpnProfile {
        val uri = Uri.parse(uriString)
        val password = uri.userInfo ?: ""
        val server = uri.host ?: "127.0.0.1"
        val port = if (uri.port > 0) uri.port else 443
        val name = URLDecoder.decode(uri.fragment ?: "Hysteria2 Server", "UTF-8")
        val sni = uri.getQueryParameter("sni") ?: server

        return VpnProfile(
            name = name,
            protocol = Protocol.HYSTERIA2,
            server = server,
            port = port,
            authKey = password,
            sni = sni,
            security = Security.TLS,
            transport = Transport.TCP,
            routeMode = RouteMode.DIRECT
        )
    }

    /**
     * Encrypts and exports profile to .sz encrypted container
     */
    fun exportToSz(profile: VpnProfile): String {
        val json = JSONObject().apply {
            put("v", 1)
            put("name", profile.name)
            put("proto", profile.protocol.name)
            put("server", profile.server)
            put("port", profile.port)
            put("auth", profile.authKey)
            put("flow", profile.flow)
            put("alterId", profile.alterId)
            put("cipher", profile.cipher)
            put("transport", profile.transport.name)
            put("sec", profile.security.name)
            put("sni", profile.sni)
            put("alpn", profile.alpn)
            put("path", profile.path)
            put("host", profile.headerHost)
            put("route", profile.routeMode.name)
            put("proxyHost", profile.proxyHost)
            put("proxyPort", profile.proxyPort)
            put("payload", profile.payload)
        }

        val plainBytes = json.toString().toByteArray(StandardCharsets.UTF_8)
        val iv = ByteArray(12).apply { java.security.SecureRandom().nextBytes(this) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val keySpec = SecretKeySpec(SZ_KEY.toByteArray(StandardCharsets.UTF_8), "AES")
        val gcmSpec = GCMParameterSpec(128, iv)
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, gcmSpec)
        val cipherBytes = cipher.doFinal(plainBytes)

        val combined = iv + cipherBytes
        return "sz://" + Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    /**
     * Decrypts profile from .sz encrypted container
     */
    fun importFromSz(szString: String): VpnProfile? {
        return try {
            val base64Data = szString.removePrefix("sz://").trim()
            val combined = Base64.decode(base64Data, Base64.DEFAULT)
            val iv = combined.copyOfRange(0, 12)
            val cipherBytes = combined.copyOfRange(12, combined.size)

            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            val keySpec = SecretKeySpec(SZ_KEY.toByteArray(StandardCharsets.UTF_8), "AES")
            val gcmSpec = GCMParameterSpec(128, iv)
            cipher.init(Cipher.DECRYPT_MODE, keySpec, gcmSpec)
            val plainBytes = cipher.doFinal(cipherBytes)

            val json = JSONObject(String(plainBytes, StandardCharsets.UTF_8))
            VpnProfile(
                name = json.optString("name", "Imported Salah VPN"),
                protocol = Protocol.valueOf(json.optString("proto", Protocol.VLESS.name)),
                server = json.optString("server", "127.0.0.1"),
                port = json.optInt("port", 443),
                authKey = json.optString("auth", ""),
                flow = json.optString("flow", ""),
                alterId = json.optInt("alterId", 0),
                cipher = json.optString("cipher", "chacha20-poly1305"),
                transport = Transport.valueOf(json.optString("transport", Transport.WS.name)),
                security = Security.valueOf(json.optString("sec", Security.TLS.name)),
                sni = json.optString("sni", ""),
                alpn = json.optString("alpn", "h2,http/1.1"),
                path = json.optString("path", "/"),
                headerHost = json.optString("host", ""),
                routeMode = RouteMode.valueOf(json.optString("route", RouteMode.DIRECT.name)),
                proxyHost = json.optString("proxyHost", ""),
                proxyPort = json.optInt("proxyPort", 8080),
                payload = json.optString("payload", "")
            )
        } catch (_: Exception) {
            null
        }
    }
}
