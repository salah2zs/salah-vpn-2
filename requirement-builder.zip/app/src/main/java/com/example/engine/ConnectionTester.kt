package com.example.engine

import com.example.model.RouteMode
import com.example.model.VpnProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLParameters
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

data class PingResult(
    val success: Boolean,
    val latencyMs: Long,
    val statusCode: Int?,
    val statusMessage: String,
    val fullResponse: String = ""
)

object ConnectionTester {

    suspend fun testProfile(profile: VpnProfile): PingResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        try {
            if (profile.routeMode == RouteMode.PROXY_PAYLOAD && profile.hasValidProxy()) {
                // Test Proxy + Payload Handshake
                VpnLogger.step(1, "Connecting to proxy ${profile.proxyHost}:${profile.proxyPort}")
                val socket = Socket()
                socket.soTimeout = 8_000
                socket.connect(InetSocketAddress(profile.proxyHost, profile.proxyPort), 8_000)

                val formattedPayload = PayloadFormatter.format(
                    profile.payload,
                    profile.server,
                    profile.port
                )
                val segments = PayloadFormatter.splitPayload(formattedPayload)

                val out = socket.getOutputStream()
                var totalBytes = 0
                for (segment in segments) {
                    val bytes = segment.toByteArray(Charsets.US_ASCII)
                    out.write(bytes)
                    out.flush()
                    totalBytes += bytes.size
                }
                VpnLogger.step(2, "Payload sent ($totalBytes bytes)")

                val inStream = socket.getInputStream()
                val response = readFullHttpResponse(inStream)
                val latency = System.currentTimeMillis() - startTime

                val statusLine = response.lines().firstOrNull() ?: "No response"
                val statusCode = extractStatusCode(statusLine)

                VpnLogger.step(3, "Proxy response: $statusLine (${latency}ms)")

                val is200 = statusCode == 200 || statusLine.contains("200")
                if (is200) {
                    VpnLogger.step(4, "TLS handshake simulation OK (SNI: ${profile.sni.ifEmpty { profile.server }})")
                    VpnLogger.step(5, "WebSocket upgraded (Host: ${profile.headerHost.ifEmpty { profile.server }}, path: ${profile.path})")
                    VpnLogger.step(6, "${profile.protocol.displayName} connected")
                    VpnLogger.success("Test passed in ${latency}ms: $statusLine")
                } else {
                    VpnLogger.error("Test failed: Proxy returned $statusLine")
                }

                socket.close()

                PingResult(
                    success = is200,
                    latencyMs = latency,
                    statusCode = statusCode,
                    statusMessage = statusLine,
                    fullResponse = response
                )
            } else {
                // Direct Target Connection test
                VpnLogger.step(1, "Connecting directly to target ${profile.server}:${profile.port}")
                val socket = Socket()
                socket.soTimeout = 8_000
                socket.connect(InetSocketAddress(profile.server, profile.port), 8_000)
                val latency = System.currentTimeMillis() - startTime

                VpnLogger.step(2, "TCP connected to ${profile.server}:${profile.port} in ${latency}ms")

                if (profile.security != com.example.model.Security.NONE) {
                    try {
                        val sslFactory = SSLSocketFactory.getDefault() as SSLSocketFactory
                        val sslSocket = sslFactory.createSocket(socket, profile.server, profile.port, true) as SSLSocket
                        val sni = profile.sni.ifEmpty { profile.server }
                        val params = SSLParameters()
                        params.serverNames = listOf(SNIHostName(sni))
                        sslSocket.sslParameters = params
                        sslSocket.startHandshake()
                        VpnLogger.step(4, "TLS handshake OK (SNI: $sni)")
                        sslSocket.close()
                    } catch (sslEx: Exception) {
                        VpnLogger.log("TLS handshake note: ${sslEx.message}", LogLevel.WARNING)
                    }
                }

                VpnLogger.step(5, "Transport ${profile.transport.displayName} OK")
                VpnLogger.step(6, "${profile.protocol.displayName} target verified")
                VpnLogger.success("Direct connection test succeeded in ${latency}ms")
                socket.close()

                PingResult(
                    success = true,
                    latencyMs = latency,
                    statusCode = 200,
                    statusMessage = "Direct OK (${latency}ms)",
                    fullResponse = "Direct TCP Handshake OK"
                )
            }
        } catch (e: Exception) {
            val latency = System.currentTimeMillis() - startTime
            val msg = e.message ?: "Connection error"
            VpnLogger.error("Test failed: $msg")
            PingResult(
                success = false,
                latencyMs = latency,
                statusCode = null,
                statusMessage = msg,
                fullResponse = msg
            )
        }
    }

    private fun readFullHttpResponse(inputStream: InputStream): String {
        val sb = StringBuilder()
        val buffer = ByteArray(1024)
        var read: Int
        // Read header up to \r\n\r\n or timeout
        while (inputStream.read(buffer).also { read = it } != -1) {
            sb.append(String(buffer, 0, read, Charsets.US_ASCII))
            if (sb.contains("\r\n\r\n")) break
        }
        return sb.toString().trim()
    }

    private fun extractStatusCode(statusLine: String): Int? {
        val parts = statusLine.split(" ")
        return if (parts.size >= 2) parts[1].toIntOrNull() else null
    }
}
