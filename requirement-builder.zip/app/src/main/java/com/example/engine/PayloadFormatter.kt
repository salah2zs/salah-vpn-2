package com.example.engine

object PayloadFormatter {

    fun format(payloadRaw: String, targetHost: String, targetPort: Int): String {
        val hostPort = "$targetHost:$targetPort"
        return payloadRaw
            .replace("[host_port]", hostPort, ignoreCase = true)
            .replace("[host]", targetHost, ignoreCase = true)
            .replace("[port]", targetPort.toString(), ignoreCase = true)
            .replace("[crlf]", "\r\n", ignoreCase = true)
            .replace("[cr]", "\r", ignoreCase = true)
            .replace("[lf]", "\n", ignoreCase = true)
    }

    /**
     * Splits payload into segments if [split] variable is present.
     */
    fun splitPayload(formattedPayload: String): List<String> {
        val splitDelimiter = "[split]"
        return if (formattedPayload.contains(splitDelimiter, ignoreCase = true)) {
            formattedPayload.split(Regex("\\[split\\]", RegexOption.IGNORE_CASE))
        } else {
            listOf(formattedPayload)
        }
    }
}
