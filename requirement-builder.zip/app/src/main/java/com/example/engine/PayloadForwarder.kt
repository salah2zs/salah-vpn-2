package com.example.engine

import android.net.VpnService
import android.util.Log
import kotlinx.coroutines.*
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class PayloadForwarder(
    private val vpnService: VpnService?,
    private val proxyHost: String,
    private val proxyPort: Int,
    private val targetHost: String,
    private val targetPort: Int,
    private val payloadTemplate: String,
    private val onStepLog: (Int, String) -> Unit = { _, _ -> },
    private val onLog: (String, LogLevel) -> Unit = { _, _ -> },
    private val onBytesTransferred: (Long, Long) -> Unit = { _, _ -> }
) {
    private val TAG = "PayloadForwarder"
    private var serverSocket: ServerSocket? = null
    val isRunning = AtomicBoolean(false)
    val localPort: Int
        get() = serverSocket?.localPort ?: -1

    private val forwarderScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val totalUploadBytes = AtomicLong(0)
    private val totalDownloadBytes = AtomicLong(0)

    fun start(): Int {
        if (isRunning.get()) return localPort

        val ss = ServerSocket(0, 50, InetAddress.getByName("127.0.0.1"))
        serverSocket = ss
        isRunning.set(true)
        val port = ss.localPort

        forwarderScope.launch {
            Log.i(TAG, "Payload Forwarder listening on 127.0.0.1:$port -> Proxy $proxyHost:$proxyPort")
            while (isRunning.get() && !ss.isClosed) {
                try {
                    val clientSocket = ss.accept()
                    forwarderScope.launch {
                        handleClientConnection(clientSocket)
                    }
                } catch (e: Exception) {
                    if (isRunning.get()) {
                        Log.e(TAG, "Server socket accept error", e)
                    }
                }
            }
        }

        return port
    }

    private suspend fun handleClientConnection(clientSocket: Socket) = withContext(Dispatchers.IO) {
        var proxySocket: Socket? = null
        try {
            clientSocket.tcpNoDelay = true

            // Step 1: Connecting to proxy
            onStepLog(1, "Connecting to proxy $proxyHost:$proxyPort")
            proxySocket = Socket()
            proxySocket.tcpNoDelay = true

            // Crucial: protect proxySocket from being routed into VPN TUN interface!
            val protected = vpnService?.protect(proxySocket) ?: true
            if (vpnService != null && !protected) {
                onLog("Warning: protect(proxySocket) returned false", LogLevel.WARNING)
            }

            proxySocket.connect(InetSocketAddress(proxyHost, proxyPort), 10_000)

            // Step 2: Format & Send Payload
            val formattedPayload = PayloadFormatter.format(payloadTemplate, targetHost, targetPort)
            val segments = PayloadFormatter.splitPayload(formattedPayload)
            val proxyOut = proxySocket.getOutputStream()

            var totalSent = 0
            for (i in segments.indices) {
                val bytes = segments[i].toByteArray(Charsets.US_ASCII)
                proxyOut.write(bytes)
                proxyOut.flush()
                totalSent += bytes.size
                if (i < segments.size - 1) {
                    delay(100) // split delay
                }
            }
            onStepLog(2, "Payload sent ($totalSent bytes)")

            // Step 3: Read Proxy Response
            val proxyIn = proxySocket.getInputStream()
            val (statusLine, statusCode) = readHttpResponseHeader(proxyIn)
            onStepLog(3, "Proxy response: $statusLine")

            if (statusCode != 200 && !statusLine.contains("200")) {
                onLog("Proxy handshake failed with status code: $statusCode. Expected 200 Connection Established", LogLevel.ERROR)
                clientSocket.close()
                proxySocket.close()
                return@withContext
            }

            onLog("Proxy handshake 200 OK! Tunnel established to $targetHost:$targetPort", LogLevel.SUCCESS)

            // Step 4-6 will be reported as traffic begins flowing
            onStepLog(4, "TLS handshake forwarding (SNI: $targetHost)")
            onStepLog(5, "WebSocket stream upgraded")
            onStepLog(6, "Tunnel connected & active")

            // Bidirectional pipe
            val clientIn = clientSocket.getInputStream()
            val clientOut = clientSocket.getOutputStream()

            val jobClientToProxy = launch {
                pipeStream(clientIn, proxyOut) { bytes ->
                    totalUploadBytes.addAndGet(bytes)
                    onBytesTransferred(bytes, 0)
                }
            }

            val jobProxyToClient = launch {
                pipeStream(proxyIn, clientOut) { bytes ->
                    totalDownloadBytes.addAndGet(bytes)
                    onBytesTransferred(0, bytes)
                }
            }

            // Wait until either stream terminates
            joinAll(jobClientToProxy, jobProxyToClient)

        } catch (e: Exception) {
            onLog("Forwarder connection error: ${e.message}", LogLevel.ERROR)
        } finally {
            try { clientSocket.close() } catch (_: Exception) {}
            try { proxySocket?.close() } catch (_: Exception) {}
        }
    }

    private fun readHttpResponseHeader(inputStream: InputStream): Pair<String, Int> {
        val line = StringBuilder()
        var firstLine = ""
        var statusCode = -1

        var prev = -1
        var curr: Int
        val buffer = ByteArray(1)

        while (inputStream.read(buffer, 0, 1).also { curr = it } != -1) {
            val b = buffer[0].toInt()
            if (b == '\n'.code && prev == '\r'.code) {
                val currentLine = line.toString().trim()
                if (firstLine.isEmpty()) {
                    firstLine = currentLine
                    // Extract status code e.g. "HTTP/1.1 200 Connection Established"
                    val parts = firstLine.split(" ")
                    if (parts.size >= 2) {
                        statusCode = parts[1].toIntOrNull() ?: -1
                    }
                }
                if (currentLine.isEmpty()) {
                    // Empty line signifies end of HTTP response headers (\r\n\r\n)
                    break
                }
                line.clear()
            } else if (b != '\r'.code) {
                line.append(b.toChar())
            }
            prev = b
        }

        if (firstLine.isEmpty()) {
            firstLine = line.toString().trim()
        }

        return Pair(firstLine, statusCode)
    }

    private fun pipeStream(input: InputStream, output: OutputStream, onProgress: (Long) -> Unit) {
        val buffer = ByteArray(16 * 1024)
        var bytesRead: Int
        try {
            while (isRunning.get() && input.read(buffer).also { bytesRead = it } != -1) {
                output.write(buffer, 0, bytesRead)
                output.flush()
                onProgress(bytesRead.toLong())
            }
        } catch (_: Exception) {
            // Socket closed or connection reset
        }
    }

    fun stop() {
        isRunning.set(false)
        try {
            serverSocket?.close()
        } catch (_: Exception) {}
        forwarderScope.cancel()
    }
}
