package com.example.engine

import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class LogLevel {
    INFO, STEP, SUCCESS, WARNING, ERROR
}

data class LogEntry(
    val timestamp: String,
    val message: String,
    val level: LogLevel = LogLevel.INFO
)

object VpnLogger {
    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())
    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs.asStateFlow()

    init {
        resetWithDeviceInfo()
    }

    fun resetWithDeviceInfo() {
        val header = mutableListOf<LogEntry>()
        val time = timeFormat.format(Date())
        header.add(
            LogEntry(
                timestamp = time,
                message = "Salah VPN v1.0 [Build 2026.10] - مطورين النت في العراق",
                level = LogLevel.INFO
            )
        )
        header.add(
            LogEntry(
                timestamp = time,
                message = "Device: ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE}, API ${Build.VERSION.SDK_INT})",
                level = LogLevel.INFO
            )
        )
        _logs.value = header
    }

    fun log(message: String, level: LogLevel = LogLevel.INFO) {
        val entry = LogEntry(
            timestamp = timeFormat.format(Date()),
            message = message,
            level = level
        )
        _logs.value = _logs.value + entry
    }

    fun step(stepNumber: Int, message: String) {
        log("[$stepNumber/6] $message", LogLevel.STEP)
    }

    fun success(message: String) {
        log("✔ $message", LogLevel.SUCCESS)
    }

    fun error(message: String) {
        log("✖ $message", LogLevel.ERROR)
    }

    fun clear() {
        resetWithDeviceInfo()
    }

    fun getAllLogsText(): String {
        return _logs.value.joinToString("\n") { "[${it.timestamp}] ${it.message}" }
    }
}
