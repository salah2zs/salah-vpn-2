package com.example.model

enum class Protocol(val displayName: String, val defaultPort: Int, val isTcpBased: Boolean) {
    VLESS("VLESS", 443, true),
    VMESS("VMess", 443, true),
    TROJAN("Trojan", 443, true),
    SHADOWSOCKS("Shadowsocks", 8388, true),
    HYSTERIA2("Hysteria2", 443, false); // UDP/QUIC based

    val supportsProxyPayload: Boolean
        get() = isTcpBased
}

enum class Transport(val displayName: String) {
    WS("WebSocket"),
    TCP("TCP"),
    GRPC("gRPC"),
    HTTP_UPGRADE("HTTPUpgrade")
}

enum class Security(val displayName: String) {
    NONE("None"),
    TLS("TLS / SSL"),
    REALITY("Reality")
}

enum class RouteMode(val displayName: String, val description: String) {
    DIRECT("Direct", "Device → TLS(SNI) → WebSocket → Target"),
    PROXY_PAYLOAD("Proxy -> Target", "Device → Proxy (CONNECT + Payload) → Target")
}
