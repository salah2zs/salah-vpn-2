package com.example.model

import java.util.UUID

data class VpnProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Salah VPN Server",
    val protocol: Protocol = Protocol.VLESS,
    val server: String = "104.21.23.45",
    val port: Int = 443,
    val authKey: String = "b831381d-6324-4d53-ad4f-8cda48b30811", // UUID or Password
    val flow: String = "",
    val alterId: Int = 0,
    val cipher: String = "chacha20-poly1305",
    val transport: Transport = Transport.WS,
    val security: Security = Security.TLS,
    val sni: String = "example.com",
    val alpn: String = "h2,http/1.1",
    val allowInsecure: Boolean = false,
    val realityPublicKey: String = "",
    val realityShortId: String = "",
    val path: String = "/vless-ws",
    val headerHost: String = "example.com",
    val serviceName: String = "",
    val routeMode: RouteMode = RouteMode.PROXY_PAYLOAD,
    val proxyHost: String = "185.199.108.153",
    val proxyPort: Int = 8080,
    val payload: String = "CONNECT [host_port] HTTP/1.1[crlf]Host: [host][crlf]User-Agent: SalahVPN/1.0[crlf][crlf]",
    val isFavorite: Boolean = false,
    val latencyMs: Long? = null,
    val lastPingStatus: String? = null,
    val createdAt: Long = System.currentTimeMillis()
) {
    val summaryLine: String
        get() {
            val secPart = when (security) {
                Security.TLS -> " SSL/TLS"
                Security.REALITY -> " Reality"
                Security.NONE -> ""
            }
            return "${protocol.displayName} · ${transport.displayName}$secPart · ${routeMode.displayName}"
        }

    val targetAddress: String
        get() = "$server:$port"

    val proxyAddress: String
        get() = if (proxyHost.isNotEmpty() && proxyPort > 0) "$proxyHost:$proxyPort" else ""

    fun hasValidProxy(): Boolean {
        return routeMode == RouteMode.PROXY_PAYLOAD && proxyHost.isNotBlank() && proxyPort > 0
    }
}
