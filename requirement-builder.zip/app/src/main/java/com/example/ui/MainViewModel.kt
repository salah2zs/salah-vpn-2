package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.VpnService
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.ProfileRepository
import com.example.engine.ConfigGenerator
import com.example.engine.ConfigParser
import com.example.engine.ConnectionTester
import com.example.engine.VpnLogger
import com.example.model.VpnProfile
import com.example.vpn.SalahVpnService
import com.example.vpn.VpnController
import com.example.vpn.VpnStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ProfileRepository

    val profiles: StateFlow<List<VpnProfile>>
    val activeProfile = VpnController.activeProfile
    val vpnStatus = VpnController.status
    val vpnStats = VpnController.stats
    val logs = VpnLogger.logs
    val selectedDns = VpnController.selectedDns

    private val _isTestingPing = MutableStateFlow(false)
    val isTestingPing: StateFlow<Boolean> = _isTestingPing.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _toastMessage = MutableSharedFlow<String>()
    val toastMessage: SharedFlow<String> = _toastMessage.asSharedFlow()

    init {
        val db = AppDatabase.getDatabase(application)
        repository = ProfileRepository(db.profileDao())
        profiles = repository.allProfiles.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        // Select the first favorite or available profile as default active if none selected
        viewModelScope.launch {
            profiles.collect { list ->
                if (VpnController.activeProfile.value == null && list.isNotEmpty()) {
                    val defaultProf = list.firstOrNull { it.isFavorite } ?: list.first()
                    VpnController.setActiveProfile(defaultProf)
                }
            }
        }
    }

    fun selectActiveProfile(profile: VpnProfile) {
        VpnController.setActiveProfile(profile)
        emitMessage("Selected: ${profile.name}")
    }

    fun toggleVpn(onPrepareVpn: (Intent) -> Unit) {
        val currentStatus = vpnStatus.value
        val context = getApplication<Application>()

        if (currentStatus == VpnStatus.CONNECTED || currentStatus == VpnStatus.CONNECTING) {
            SalahVpnService.stop(context)
        } else {
            val profile = activeProfile.value
            if (profile == null) {
                emitMessage("Please select or create a connection first")
                return
            }

            // Check if VPN preparation permission is needed
            val prepareIntent = VpnService.prepare(context)
            if (prepareIntent != null) {
                onPrepareVpn(prepareIntent)
            } else {
                startVpnDirectly()
            }
        }
    }

    fun startVpnDirectly() {
        val context = getApplication<Application>()
        SalahVpnService.start(context)
    }

    fun saveProfile(profile: VpnProfile) {
        viewModelScope.launch {
            repository.saveProfile(profile)
            if (activeProfile.value?.id == profile.id || activeProfile.value == null) {
                VpnController.setActiveProfile(profile)
            }
            emitMessage("Saved connection: ${profile.name}")
        }
    }

    fun deleteProfile(id: String) {
        viewModelScope.launch {
            repository.deleteProfile(id)
            if (activeProfile.value?.id == id) {
                val remaining = profiles.value.filter { it.id != id }
                VpnController.setActiveProfile(remaining.firstOrNull())
            }
            emitMessage("Deleted connection")
        }
    }

    fun toggleFavorite(profile: VpnProfile) {
        viewModelScope.launch {
            repository.toggleFavorite(profile.id, profile.isFavorite)
        }
    }

    fun duplicateProfile(profile: VpnProfile) {
        viewModelScope.launch {
            val copy = profile.copy(
                id = java.util.UUID.randomUUID().toString(),
                name = "${profile.name} (Copy)",
                createdAt = System.currentTimeMillis()
            )
            repository.saveProfile(copy)
            emitMessage("Duplicated profile")
        }
    }

    fun testProfilePing(profile: VpnProfile) {
        viewModelScope.launch {
            _isTestingPing.value = true
            val result = ConnectionTester.testProfile(profile)
            val statusStr = if (result.success) "${result.latencyMs}ms (${result.statusMessage})" else "Failed"
            repository.updateLatency(profile.id, if (result.success) result.latencyMs else null, statusStr)

            if (activeProfile.value?.id == profile.id) {
                VpnController.setActiveProfile(profile.copy(
                    latencyMs = if (result.success) result.latencyMs else null,
                    lastPingStatus = statusStr
                ))
            }
            _isTestingPing.value = false
            emitMessage(if (result.success) "Latency: ${result.latencyMs}ms" else "Test failed: ${result.statusMessage}")
        }
    }

    fun testAllPings() {
        viewModelScope.launch {
            _isTestingPing.value = true
            profiles.value.forEach { profile ->
                val result = ConnectionTester.testProfile(profile)
                repository.updateLatency(profile.id, if (result.success) result.latencyMs else null, result.statusMessage)
            }
            _isTestingPing.value = false
            emitMessage("Tested all connections")
        }
    }

    fun importConfigText(rawText: String) {
        viewModelScope.launch {
            val trimmed = rawText.trim()
            val profile = when {
                trimmed.startsWith("sz://", ignoreCase = true) -> ConfigParser.importFromSz(trimmed)
                else -> ConfigParser.parseUri(trimmed)
            }

            if (profile != null) {
                repository.saveProfile(profile)
                VpnController.setActiveProfile(profile)
                emitMessage("Imported: ${profile.name}")
            } else {
                emitMessage("Unrecognized link format. Supports vless://, vmess://, trojan://, ss://, hy2://, and sz://")
            }
        }
    }

    fun exportProfileAsSz(profile: VpnProfile): String {
        return ConfigParser.exportToSz(profile)
    }

    fun exportProfileAsJson(profile: VpnProfile): String {
        return ConfigGenerator.buildFullSingBoxConfig(profile, dnsServer = selectedDns.value).toString(2)
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateDns(dns: String) {
        VpnController.setDns(dns)
        emitMessage("DNS updated to: $dns")
    }

    fun clearLogs() {
        VpnLogger.clear()
        emitMessage("Logs cleared")
    }

    private fun emitMessage(msg: String) {
        viewModelScope.launch {
            _toastMessage.emit(msg)
        }
    }
}
