package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Protocol
import com.example.model.RouteMode
import com.example.model.Transport
import com.example.ui.theme.*

@Composable
fun SummaryStrip(
    protocol: Protocol,
    transport: Transport,
    routeMode: RouteMode,
    onProtocolChange: (Protocol) -> Unit,
    onTransportChange: (Transport) -> Unit,
    onRouteChange: (RouteMode) -> Unit,
    modifier: Modifier = Modifier
) {
    var protocolExpanded by remember { mutableStateOf(false) }
    var transportExpanded by remember { mutableStateOf(false) }
    var routeExpanded by remember { mutableStateOf(false) }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(NavySurfaceVariant.copy(alpha = 0.7f))
            .border(1.dp, SkyBluePrimary.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Protocol part
        Box {
            SummaryPill(
                text = protocol.displayName,
                onClick = { protocolExpanded = true },
                tag = "protocol_summary_pill"
            )
            DropdownMenu(
                expanded = protocolExpanded,
                onDismissRequest = { protocolExpanded = false },
                modifier = Modifier.background(NavySurface)
            ) {
                Protocol.values().forEach { proto ->
                    DropdownMenuItem(
                        text = {
                            Text(
                                proto.displayName,
                                color = if (proto == protocol) SkyBluePrimary else TextPrimary
                            )
                        },
                        onClick = {
                            onProtocolChange(proto)
                            protocolExpanded = false
                        }
                    )
                }
            }
        }

        Text(
            text = "·",
            color = SkyBlueTertiary,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )

        // Transport part
        Box {
            SummaryPill(
                text = transport.displayName,
                onClick = { transportExpanded = true },
                tag = "transport_summary_pill"
            )
            DropdownMenu(
                expanded = transportExpanded,
                onDismissRequest = { transportExpanded = false },
                modifier = Modifier.background(NavySurface)
            ) {
                Transport.values().forEach { tr ->
                    DropdownMenuItem(
                        text = {
                            Text(
                                tr.displayName,
                                color = if (tr == transport) SkyBluePrimary else TextPrimary
                            )
                        },
                        onClick = {
                            onTransportChange(tr)
                            transportExpanded = false
                        }
                    )
                }
            }
        }

        Text(
            text = "·",
            color = SkyBlueTertiary,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )

        // Route part (Direct vs Proxy -> Target)
        Box {
            SummaryPill(
                text = routeMode.displayName,
                onClick = { routeExpanded = true },
                tag = "route_summary_pill"
            )
            DropdownMenu(
                expanded = routeExpanded,
                onDismissRequest = { routeExpanded = false },
                modifier = Modifier.background(NavySurface)
            ) {
                RouteMode.values().forEach { mode ->
                    val isEnabled = mode != RouteMode.PROXY_PAYLOAD || protocol.supportsProxyPayload
                    DropdownMenuItem(
                        enabled = isEnabled,
                        text = {
                            Column {
                                Text(
                                    mode.displayName,
                                    color = if (mode == routeMode) SkyBluePrimary else if (isEnabled) TextPrimary else TextTertiary,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    mode.description,
                                    fontSize = 10.sp,
                                    color = TextTertiary
                                )
                            }
                        },
                        onClick = {
                            onRouteChange(mode)
                            routeExpanded = false
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun SummaryPill(
    text: String,
    onClick: () -> Unit,
    tag: String
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = text,
            color = SkyBlueSecondary,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
        )
        Icon(
            imageVector = Icons.Default.ArrowDropDown,
            contentDescription = "Expand $text",
            tint = SkyBlueTertiary,
            modifier = Modifier.size(18.dp)
        )
    }
}
