package com.example.ui.screens

import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.ConnectionTester
import com.example.engine.VpnLogger
import com.example.model.Protocol
import com.example.model.RouteMode
import com.example.model.Security
import com.example.model.Transport
import com.example.model.VpnProfile
import com.example.ui.MainViewModel
import com.example.ui.components.LogView
import com.example.ui.components.SummaryStrip
import com.example.ui.theme.*
import com.example.vpn.VpnStatus
import kotlinx.coroutines.launch

@Composable
fun EditorScreen(
    profileId: String?,
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val profiles by viewModel.profiles.collectAsState()
    val vpnStatus by viewModel.vpnStatus.collectAsState()
    val logs by viewModel.logs.collectAsState()

    // Handle system back
    BackHandler { onNavigateBack() }

    // Load initial profile or create new empty profile per Section 7.3
    val initialProfile = remember(profileId, profiles) {
        if (profileId != null) {
            profiles.firstOrNull { it.id == profileId } ?: VpnProfile()
        } else {
            // New profile starts fresh
            VpnProfile(
                name = "New Connection",
                server = "",
                port = 443,
                authKey = "",
                path = "",
                sni = "",
                headerHost = "",
                proxyHost = "",
                proxyPort = 8080,
                payload = "CONNECT [host_port] HTTP/1.1[crlf]Host: [host][crlf]Connection: Keep-Alive[crlf][crlf]",
                routeMode = RouteMode.DIRECT
            )
        }
    }

    var name by remember { mutableStateOf(initialProfile.name) }
    var protocol by remember { mutableStateOf(initialProfile.protocol) }
    var transport by remember { mutableStateOf(initialProfile.transport) }
    var security by remember { mutableStateOf(initialProfile.security) }
    var routeMode by remember { mutableStateOf(initialProfile.routeMode) }

    var targetServer by remember { mutableStateOf(if (initialProfile.server.isNotEmpty()) "${initialProfile.server}:${initialProfile.port}" else "") }
    var authKey by remember { mutableStateOf(initialProfile.authKey) }
    var path by remember { mutableStateOf(initialProfile.path) }
    var sni by remember { mutableStateOf(initialProfile.sni) }
    var headerHost by remember { mutableStateOf(initialProfile.headerHost) }
    var proxyAddress by remember { mutableStateOf(if (initialProfile.proxyHost.isNotEmpty()) "${initialProfile.proxyHost}:${initialProfile.proxyPort}" else "") }
    var payload by remember { mutableStateOf(initialProfile.payload) }
    var isFavorite by remember { mutableStateOf(initialProfile.isFavorite) }

    var isTestingConnection by remember { mutableStateOf(false) }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.startVpnDirectly()
        }
    }

    fun buildCurrentProfile(): VpnProfile {
        val targetParts = targetServer.trim().split(":")
        val serverHost = targetParts.getOrNull(0) ?: ""
        val serverPort = targetParts.getOrNull(1)?.toIntOrNull() ?: protocol.defaultPort

        val proxyParts = proxyAddress.trim().split(":")
        val pHost = proxyParts.getOrNull(0) ?: ""
        val pPort = proxyParts.getOrNull(1)?.toIntOrNull() ?: 8080

        return initialProfile.copy(
            name = name.ifBlank { "Salah VPN Connection" },
            protocol = protocol,
            server = serverHost,
            port = serverPort,
            authKey = authKey,
            transport = transport,
            security = security,
            sni = sni,
            headerHost = headerHost,
            path = path,
            routeMode = routeMode,
            proxyHost = pHost,
            proxyPort = pPort,
            payload = payload,
            isFavorite = isFavorite
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = NavyDarkBackground,
        topBar = {
            // 1. Top Bar per Section 7.3: App name, menu, delete, favorite
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("editor_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = SkyBlueSecondary
                        )
                    }
                    Text(
                        text = "Salah VPN",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Favorite Heart Icon
                    IconButton(
                        onClick = { isFavorite = !isFavorite },
                        modifier = Modifier.testTag("editor_favorite_toggle")
                    ) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (isFavorite) StatusError else TextSecondary
                        )
                    }

                    // Delete Icon (if editing existing profile)
                    if (profileId != null) {
                        IconButton(
                            onClick = {
                                viewModel.deleteProfile(profileId)
                                onNavigateBack()
                            },
                            modifier = Modifier.testTag("editor_delete_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete",
                                tint = StatusError
                            )
                        }
                    }

                    // Save Check Icon
                    IconButton(
                        onClick = {
                            val p = buildCurrentProfile()
                            viewModel.saveProfile(p)
                            onNavigateBack()
                        },
                        modifier = Modifier.testTag("editor_save_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Save",
                            tint = SkyBluePrimary
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            // Connection Name field
            item {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Connection Name", fontSize = 12.sp, color = SkyBlueSecondary) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SkyBluePrimary,
                        unfocusedBorderColor = NavyCardBorder,
                        focusedContainerColor = NavySurface,
                        unfocusedContainerColor = NavySurface,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                        .testTag("profile_name_input")
                )
            }

            // 2. Summary Line: Protocol · Transport · Route (per Section 7.2 & 7.3)
            item {
                SummaryStrip(
                    protocol = protocol,
                    transport = transport,
                    routeMode = routeMode,
                    onProtocolChange = { newProto ->
                        protocol = newProto
                        if (!newProto.supportsProxyPayload && routeMode == RouteMode.PROXY_PAYLOAD) {
                            routeMode = RouteMode.DIRECT
                        }
                    },
                    onTransportChange = { transport = it },
                    onRouteChange = { routeMode = it }
                )
                Spacer(modifier = Modifier.height(14.dp))
            }

            // 3. Field Card (Vertical order from Section 7.3)
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(NavySurface)
                        .border(1.dp, NavyCardBorder, RoundedCornerShape(18.dp))
                        .padding(16.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        // 1. Target Server (host:port)
                        EditorFieldRow(
                            label = "Target server (host:port)",
                            value = targetServer,
                            placeholder = "104.21.23.45:443",
                            onValueChange = { targetServer = it },
                            tag = "target_server_input"
                        )

                        // 2. Auth: uuid (or password according to protocol)
                        val authLabel = when (protocol) {
                            Protocol.VLESS, Protocol.VMESS -> "uuid"
                            Protocol.TROJAN, Protocol.HYSTERIA2 -> "password"
                            Protocol.SHADOWSOCKS -> "password"
                        }
                        EditorFieldRow(
                            label = authLabel,
                            value = authKey,
                            placeholder = if (authLabel == "uuid") "b831381d-6324-4d53-ad4f-8cda48b30811" else "your_secret_password",
                            onValueChange = { authKey = it },
                            tag = "auth_key_input"
                        )

                        // 3. Path (WebSocket Path)
                        EditorFieldRow(
                            label = "path",
                            value = path,
                            placeholder = "/vless-ws",
                            onValueChange = { path = it },
                            tag = "ws_path_input"
                        )

                        // 4. Server Name Indication (SNI)
                        EditorFieldRow(
                            label = "Server name indication (SNI)",
                            value = sni,
                            placeholder = "example.com",
                            onValueChange = { sni = it },
                            tag = "sni_input"
                        )

                        // 5. Header Host
                        EditorFieldRow(
                            label = "Header host",
                            value = headerHost,
                            placeholder = "example.com",
                            onValueChange = { headerHost = it },
                            tag = "header_host_input"
                        )

                        // 6 & 7: Proxy & Payload (Visible only if routeMode == PROXY_PAYLOAD)
                        if (routeMode == RouteMode.PROXY_PAYLOAD && protocol.supportsProxyPayload) {
                            Divider(color = SkyBluePrimary.copy(alpha = 0.3f), thickness = 1.dp)

                            // 6. Proxy (host:port)
                            EditorFieldRow(
                                label = "Proxy (host:port)",
                                value = proxyAddress,
                                placeholder = "185.199.108.153:8080",
                                onValueChange = { proxyAddress = it },
                                tag = "proxy_address_input"
                            )

                            // 7. Payload (multi-line)
                            Column {
                                Text(
                                    text = "Payload",
                                    fontSize = 11.sp,
                                    color = SkyBlueSecondary,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                OutlinedTextField(
                                    value = payload,
                                    onValueChange = { payload = it },
                                    minLines = 3,
                                    maxLines = 6,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = SkyBluePrimary,
                                        unfocusedBorderColor = NavyCardBorder,
                                        focusedContainerColor = NavyDarkBackground,
                                        unfocusedContainerColor = NavyDarkBackground,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("payload_input")
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                // Quick Variable Insertion Chips (Section 3)
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    val vars = listOf("[host_port]", "[host]", "[port]", "[crlf]", "[split]")
                                    items(vars) { v ->
                                        SuggestionChip(
                                            onClick = { payload += v },
                                            label = { Text(v, fontSize = 10.sp, color = CyanAccent) },
                                            colors = SuggestionChipDefaults.suggestionChipColors(
                                                containerColor = NavySurfaceVariant
                                            ),
                                            border = SuggestionChipDefaults.suggestionChipBorder(
                                                enabled = true,
                                                borderColor = SkyBluePrimary.copy(alpha = 0.3f)
                                            )
                                        )
                                    }
                                }
                            }
                        }

                        // Test Connection Button inside Editor
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            OutlinedButton(
                                onClick = {
                                    val testProfile = buildCurrentProfile()
                                    isTestingConnection = true
                                    coroutineScope.launch {
                                        val result = ConnectionTester.testProfile(testProfile)
                                        isTestingConnection = false
                                        val msg = if (result.success) {
                                            "Test Succeeded! Latency: ${result.latencyMs}ms (${result.statusMessage})"
                                        } else {
                                            "Test Failed: ${result.statusMessage}"
                                        }
                                        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                    }
                                },
                                enabled = !isTestingConnection && targetServer.isNotBlank(),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = SkyBlueTertiary),
                                modifier = Modifier.testTag("test_connection_editor_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Bolt,
                                    contentDescription = "Test connection",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isTestingConnection) "Testing..." else "Test Connection",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // 4. Connect Button: Full-width, directly below the card per Section 7.3
            item {
                val isConnected = vpnStatus == VpnStatus.CONNECTED
                Button(
                    onClick = {
                        val current = buildCurrentProfile()
                        viewModel.saveProfile(current)
                        viewModel.selectActiveProfile(current)
                        viewModel.toggleVpn { intent ->
                            vpnPermissionLauncher.launch(intent)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("editor_connect_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isConnected) StatusConnected else SkyBluePrimary,
                        contentColor = NavyDarkBackground
                    )
                ) {
                    Icon(
                        imageVector = if (isConnected) Icons.Default.Stop else Icons.Default.PlayArrow,
                        contentDescription = "Connect",
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isConnected) "DISCONNECT VPN" else "CONNECT NOW",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // 5. Log area: Monospace font under button per Section 7.3
            item {
                LogView(
                    logs = logs,
                    onClear = { viewModel.clearLogs() },
                    title = "Connection Trace & Log"
                )
            }
        }
    }
}

@Composable
private fun EditorFieldRow(
    label: String,
    value: String,
    placeholder: String,
    onValueChange: (String) -> Unit,
    tag: String
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = SkyBlueSecondary,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(3.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            placeholder = { Text(placeholder, fontSize = 12.sp, color = TextTertiary) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = SkyBluePrimary,
                unfocusedBorderColor = NavyCardBorder.copy(alpha = 0.7f),
                focusedContainerColor = NavyDarkBackground,
                unfocusedContainerColor = NavyDarkBackground,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag(tag)
        )
        Divider(
            color = NavyCardBorder.copy(alpha = 0.4f),
            thickness = 0.5.dp,
            modifier = Modifier.padding(top = 8.dp)
        )
    }
}
