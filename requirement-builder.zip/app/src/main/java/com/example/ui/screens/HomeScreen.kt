package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.LogEntry
import com.example.model.VpnProfile
import com.example.ui.MainViewModel
import com.example.ui.components.LogView
import com.example.ui.components.SpeedMetricsRow
import com.example.ui.theme.*
import com.example.vpn.VpnStatistics
import com.example.vpn.VpnStatus

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateToProxyBoard: () -> Unit,
    onNavigateToEditor: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    val vpnStatus by viewModel.vpnStatus.collectAsState()
    val activeProfile by viewModel.activeProfile.collectAsState()
    val stats by viewModel.vpnStats.collectAsState()
    val logs by viewModel.logs.collectAsState()
    val isTestingPing by viewModel.isTestingPing.collectAsState()

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.startVpnDirectly()
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDarkBackground)
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp)
    ) {
        // App Header & Iraqi Dev Attribution
        item {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(bottom = 20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.VpnKey,
                        contentDescription = "Salah VPN",
                        tint = SkyBluePrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Salah VPN",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary,
                        letterSpacing = 1.sp
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "مطورين النت في العراق",
                    fontSize = 12.sp,
                    color = SkyBlueSecondary,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Big Connect Button with Radar Pulse Animation
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                ConnectButton(
                    vpnStatus = vpnStatus,
                    durationSeconds = stats.connectionDurationSeconds,
                    onClick = {
                        viewModel.toggleVpn { intent ->
                            vpnPermissionLauncher.launch(intent)
                        }
                    }
                )
            }
        }

        // Live Upload / Download Speed Card
        item {
            Spacer(modifier = Modifier.height(8.dp))
            SpeedMetricsRow(
                uploadSpeedBps = stats.uploadSpeedBps,
                downloadSpeedBps = stats.downloadSpeedBps,
                totalUploadBytes = stats.totalUploadBytes,
                totalDownloadBytes = stats.totalDownloadBytes
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Active Profile Card
        item {
            ActiveProfileCard(
                profile = activeProfile,
                isTestingPing = isTestingPing,
                onTestPing = { activeProfile?.let { viewModel.testProfilePing(it) } },
                onChangeClick = onNavigateToProxyBoard,
                onEditClick = { onNavigateToEditor(activeProfile?.id) }
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Live Monospace Logs directly below Connect Button (as specified in Section 7 & 7.2)
        item {
            LogView(
                logs = logs,
                onClear = { viewModel.clearLogs() },
                title = "Live Connection Log"
            )
        }
    }
}

@Composable
private fun ConnectButton(
    vpnStatus: VpnStatus,
    durationSeconds: Long,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (vpnStatus == VpnStatus.CONNECTING || vpnStatus == VpnStatus.CONNECTED) 1.15f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val (buttonColor, glowColor, statusText) = when (vpnStatus) {
        VpnStatus.CONNECTED -> Triple(StatusConnected, StatusConnected.copy(alpha = 0.35f), "CONNECTED")
        VpnStatus.CONNECTING -> Triple(StatusConnecting, StatusConnecting.copy(alpha = 0.35f), "CONNECTING...")
        VpnStatus.DISCONNECTING -> Triple(StatusConnecting, StatusConnecting.copy(alpha = 0.2f), "DISCONNECTING")
        VpnStatus.ERROR -> Triple(StatusError, StatusError.copy(alpha = 0.35f), "ERROR")
        VpnStatus.DISCONNECTED -> Triple(SkyBluePrimary, SkyBluePrimary.copy(alpha = 0.25f), "TAP TO CONNECT")
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(190.dp)
        ) {
            // Pulsing Outer Radar Ring
            Box(
                modifier = Modifier
                    .size(175.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(glowColor)
            )

            // Inner Button
            Box(
                modifier = Modifier
                    .size(150.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                NavySurfaceVariant,
                                NavySurface
                            )
                        )
                    )
                    .border(3.dp, buttonColor, CircleShape)
                    .clickable(onClick = onClick)
                    .testTag("vpn_connect_button"),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.PowerSettingsNew,
                        contentDescription = "Connect Button",
                        tint = buttonColor,
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = statusText,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = buttonColor,
                        letterSpacing = 0.5.sp
                    )
                    if (vpnStatus == VpnStatus.CONNECTED) {
                        val hours = durationSeconds / 3600
                        val minutes = (durationSeconds % 3600) / 60
                        val secs = durationSeconds % 60
                        val timeStr = if (hours > 0) {
                            String.format("%02d:%02d:%02d", hours, minutes, secs)
                        } else {
                            String.format("%02d:%02d", minutes, secs)
                        }
                        Text(
                            text = timeStr,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ActiveProfileCard(
    profile: VpnProfile?,
    isTestingPing: Boolean,
    onTestPing: () -> Unit,
    onChangeClick: () -> Unit,
    onEditClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(NavySurface)
            .border(1.dp, NavyCardBorder, RoundedCornerShape(18.dp))
            .padding(16.dp)
    ) {
        if (profile == null) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "No Connection Selected",
                    fontSize = 14.sp,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = onChangeClick,
                    colors = ButtonDefaults.buttonColors(containerColor = SkyBluePrimary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Select from Proxy Board", color = NavyDarkBackground, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = profile.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = profile.summaryLine,
                            fontSize = 12.sp,
                            color = SkyBlueSecondary,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    // Ping Latency Pill
                    PingPill(
                        latencyMs = profile.latencyMs,
                        isTesting = isTestingPing,
                        onClick = onTestPing
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Divider(color = NavyCardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Target: ${profile.targetAddress}",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                        if (profile.hasValidProxy()) {
                            Text(
                                text = "Proxy: ${profile.proxyAddress}",
                                fontSize = 11.sp,
                                color = CyanAccent
                            )
                        }
                    }

                    Row {
                        IconButton(
                            onClick = onEditClick,
                            modifier = Modifier.size(36.dp).testTag("edit_active_profile_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit Profile",
                                tint = SkyBlueTertiary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(
                            onClick = onChangeClick,
                            modifier = Modifier.size(36.dp).testTag("change_active_profile_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.SwapHoriz,
                                contentDescription = "Change Profile",
                                tint = SkyBluePrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PingPill(
    latencyMs: Long?,
    isTesting: Boolean,
    onClick: () -> Unit
) {
    val (bgColor, textColor, text) = when {
        isTesting -> Triple(NavySurfaceVariant, SkyBlueTertiary, "Testing...")
        latencyMs == null -> Triple(NavySurfaceVariant, TextSecondary, "Ping")
        latencyMs < 120 -> Triple(StatusConnected.copy(alpha = 0.15f), StatusConnected, "${latencyMs}ms")
        latencyMs < 350 -> Triple(StatusConnecting.copy(alpha = 0.15f), StatusConnecting, "${latencyMs}ms")
        else -> Triple(StatusError.copy(alpha = 0.15f), StatusError, "${latencyMs}ms")
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .border(0.8.dp, textColor.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag("ping_test_pill"),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(textColor)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = text,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = textColor
            )
        }
    }
}
