package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Protocol
import com.example.model.VpnProfile
import com.example.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun ProxyBoardScreen(
    viewModel: MainViewModel,
    onNavigateToEditor: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val profiles by viewModel.profiles.collectAsState()
    val activeProfile by viewModel.activeProfile.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val isTestingPing by viewModel.isTestingPing.collectAsState()

    var selectedProtocolFilter by remember { mutableStateOf<Protocol?>(null) }
    var showImportDialog by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf<VpnProfile?>(null) }
    var importInputText by remember { mutableStateOf("") }

    val filteredProfiles = remember(profiles, searchQuery, selectedProtocolFilter) {
        profiles.filter { p ->
            val matchesQuery = searchQuery.isBlank() ||
                p.name.contains(searchQuery, ignoreCase = true) ||
                p.server.contains(searchQuery, ignoreCase = true) ||
                p.proxyHost.contains(searchQuery, ignoreCase = true)
            val matchesProtocol = selectedProtocolFilter == null || p.protocol == selectedProtocolFilter
            matchesQuery && matchesProtocol
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = NavyDarkBackground,
        floatingActionButton = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(bottom = 80.dp)
            ) {
                FloatingActionButton(
                    onClick = { showImportDialog = true },
                    containerColor = NavySurfaceVariant,
                    contentColor = SkyBlueSecondary,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.testTag("import_link_fab")
                ) {
                    Icon(imageVector = Icons.Default.Link, contentDescription = "Import link")
                }

                FloatingActionButton(
                    onClick = { onNavigateToEditor(null) },
                    containerColor = SkyBluePrimary,
                    contentColor = NavyDarkBackground,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.testTag("add_profile_fab")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add profile")
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp)
        ) {
            // Header Bar
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Proxy Board",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            color = TextPrimary
                        )
                        Text(
                            text = "${filteredProfiles.size} Connections available",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }

                    // Test All Pings button
                    OutlinedButton(
                        onClick = { viewModel.testAllPings() },
                        enabled = !isTestingPing && profiles.isNotEmpty(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = SkyBlueSecondary
                        ),
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = androidx.compose.ui.graphics.SolidColor(SkyBlueSecondary.copy(alpha = 0.5f))
                        ),
                        modifier = Modifier.testTag("test_all_pings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.NetworkCheck,
                            contentDescription = "Test all pings",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isTestingPing) "Testing..." else "Test Pings",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    placeholder = { Text("Search by name, server or proxy...", fontSize = 13.sp, color = TextTertiary) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = SkyBlueSecondary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear search", tint = TextSecondary)
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SkyBluePrimary,
                        unfocusedBorderColor = NavyCardBorder,
                        focusedContainerColor = NavySurface,
                        unfocusedContainerColor = NavySurface,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_profiles_input")
                )

                Spacer(modifier = Modifier.height(12.dp))
            }

            // Protocol Filter Chips
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = selectedProtocolFilter == null,
                            onClick = { selectedProtocolFilter = null },
                            label = { Text("All") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = SkyBluePrimary,
                                selectedLabelColor = NavyDarkBackground,
                                containerColor = NavySurface,
                                labelColor = TextSecondary
                            )
                        )
                    }
                    items(Protocol.values()) { proto ->
                        FilterChip(
                            selected = selectedProtocolFilter == proto,
                            onClick = { selectedProtocolFilter = proto },
                            label = { Text(proto.displayName) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = SkyBluePrimary,
                                selectedLabelColor = NavyDarkBackground,
                                containerColor = NavySurface,
                                labelColor = TextSecondary
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // Profile List or Empty State
            if (filteredProfiles.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.FolderOpen,
                                contentDescription = "No profiles",
                                tint = TextTertiary,
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "No connections found",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Add a new connection or import a link",
                                fontSize = 12.sp,
                                color = TextTertiary
                            )
                        }
                    }
                }
            } else {
                items(filteredProfiles, key = { it.id }) { profile ->
                    val isActive = activeProfile?.id == profile.id
                    ProfileItemCard(
                        profile = profile,
                        isActive = isActive,
                        isTestingPing = isTestingPing,
                        onSelect = { viewModel.selectActiveProfile(profile) },
                        onTestPing = { viewModel.testProfilePing(profile) },
                        onToggleFavorite = { viewModel.toggleFavorite(profile) },
                        onEdit = { onNavigateToEditor(profile.id) },
                        onDuplicate = { viewModel.duplicateProfile(profile) },
                        onExport = { showExportDialog = profile },
                        onDelete = { viewModel.deleteProfile(profile.id) }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }
        }
    }

    // Import Link Dialog
    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            containerColor = NavySurface,
            title = {
                Text(
                    text = "Import Connection Link",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            },
            text = {
                Column {
                    Text(
                        text = "Paste a vless://, vmess://, trojan://, ss://, hy2:// link or .sz encrypted config:",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = importInputText,
                        onValueChange = { importInputText = it },
                        placeholder = { Text("vless://... or sz://...", fontSize = 12.sp, color = TextTertiary) },
                        maxLines = 4,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("import_link_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SkyBluePrimary,
                            unfocusedBorderColor = NavyCardBorder,
                            focusedContainerColor = NavyDarkBackground,
                            unfocusedContainerColor = NavyDarkBackground,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = clipboard.primaryClip
                            if (clip != null && clip.itemCount > 0) {
                                importInputText = clip.getItemAt(0).text.toString()
                            }
                        }
                    ) {
                        Icon(Icons.Default.ContentPaste, contentDescription = "Paste", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Paste from Clipboard", color = SkyBlueSecondary, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (importInputText.isNotBlank()) {
                            viewModel.importConfigText(importInputText)
                            importInputText = ""
                            showImportDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SkyBluePrimary)
                ) {
                    Text("Import", color = NavyDarkBackground, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }

    // Export Dialog
    showExportDialog?.let { profileToExport ->
        val szText = remember(profileToExport) { viewModel.exportProfileAsSz(profileToExport) }
        val jsonText = remember(profileToExport) { viewModel.exportProfileAsJson(profileToExport) }

        AlertDialog(
            onDismissRequest = { showExportDialog = null },
            containerColor = NavySurface,
            title = {
                Text(
                    text = "Export: ${profileToExport.name}",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            },
            text = {
                Column {
                    Text("Encrypted .sz format (AES-GCM):", fontSize = 12.sp, color = SkyBlueSecondary, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = szText.take(60) + "...",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Button(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText(".sz Encrypted Config", szText))
                            Toast.makeText(context, ".sz copied to clipboard", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NavySurfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Copy .sz String", color = SkyBluePrimary)
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Sing-box JSON format:", fontSize = 12.sp, color = CyanAccent, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Button(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Sing-box JSON", jsonText))
                            Toast.makeText(context, "Sing-box JSON copied to clipboard", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NavySurfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Copy sing-box JSON", color = CyanAccent)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showExportDialog = null }) {
                    Text("Close", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun ProfileItemCard(
    profile: VpnProfile,
    isActive: Boolean,
    isTestingPing: Boolean,
    onSelect: () -> Unit,
    onTestPing: () -> Unit,
    onToggleFavorite: () -> Unit,
    onEdit: () -> Unit,
    onDuplicate: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (isActive) NavySurfaceVariant else NavySurface)
            .border(
                width = if (isActive) 1.5.dp else 1.dp,
                color = if (isActive) SkyBluePrimary else NavyCardBorder,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onSelect)
            .padding(14.dp)
            .testTag("profile_card_${profile.id}")
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Active Radio Indicator
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .clip(CircleShape)
                        .border(
                            2.dp,
                            if (isActive) SkyBluePrimary else TextTertiary,
                            CircleShape
                        )
                        .padding(3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (isActive) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .background(SkyBluePrimary)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                // Title & Protocol badge
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = profile.name,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = profile.summaryLine,
                        fontSize = 11.sp,
                        color = SkyBlueSecondary
                    )
                }

                // Ping Pill
                PingPill(
                    latencyMs = profile.latencyMs,
                    isTesting = isTestingPing,
                    onClick = onTestPing
                )

                // Favorite Heart Button
                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier.size(36.dp).testTag("favorite_button_${profile.id}")
                ) {
                    Icon(
                        imageVector = if (profile.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (profile.isFavorite) StatusError else TextTertiary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // More Menu Button
                Box {
                    IconButton(
                        onClick = { menuExpanded = true },
                        modifier = Modifier.size(36.dp).testTag("more_menu_button_${profile.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "Options",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false },
                        modifier = Modifier.background(NavySurface)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Edit Connection", color = TextPrimary) },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = SkyBluePrimary) },
                            onClick = {
                                menuExpanded = false
                                onEdit()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Duplicate", color = TextPrimary) },
                            leadingIcon = { Icon(Icons.Default.ContentCopy, contentDescription = null, tint = SkyBlueTertiary) },
                            onClick = {
                                menuExpanded = false
                                onDuplicate()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Export (.sz / JSON)", color = TextPrimary) },
                            leadingIcon = { Icon(Icons.Default.Share, contentDescription = null, tint = CyanAccent) },
                            onClick = {
                                menuExpanded = false
                                onExport()
                            }
                        )
                        Divider(color = NavyCardBorder, thickness = 0.5.dp)
                        DropdownMenuItem(
                            text = { Text("Delete", color = StatusError) },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = StatusError) },
                            onClick = {
                                menuExpanded = false
                                onDelete()
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Sub-details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Target: ${profile.targetAddress}",
                    fontSize = 11.sp,
                    color = TextTertiary
                )
                if (profile.hasValidProxy()) {
                    Text(
                        text = "Proxy: ${profile.proxyAddress}",
                        fontSize = 11.sp,
                        color = SkyBlueTertiary
                    )
                }
            }
        }
    }
}
