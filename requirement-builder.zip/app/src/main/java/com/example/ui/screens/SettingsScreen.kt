package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedDns by viewModel.selectedDns.collectAsState()
    var showDnsDialog by remember { mutableStateOf(false) }
    var customDnsInput by remember { mutableStateOf("") }

    val dnsPresets = listOf(
        Pair("Google DNS", "8.8.8.8"),
        Pair("Cloudflare DNS", "1.1.1.1"),
        Pair("AdGuard DNS", "94.140.14.14"),
        Pair("Quad9 DNS", "9.9.9.9")
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDarkBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp)
    ) {
        item {
            Text(
                text = "Settings",
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                color = TextPrimary
            )
            Text(
                text = "DNS, Routing & Tunnel Preferences",
                fontSize = 12.sp,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Section: Network & DNS
        item {
            SettingsCategoryHeader("Network & Routing")
            SettingsCard {
                SettingsClickableItem(
                    title = "DNS Server",
                    subtitle = selectedDns,
                    icon = Icons.Default.Dns,
                    onClick = { showDnsDialog = true },
                    tag = "dns_settings_item"
                )
                Divider(color = NavyCardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
                SettingsClickableItem(
                    title = "Per-App Exclusions",
                    subtitle = "App self-package excluded (protect loop safeguard)",
                    icon = Icons.Default.Apps,
                    onClick = {
                        Toast.makeText(context, "Salah VPN self-package is protected and excluded from TUN", Toast.LENGTH_SHORT).show()
                    },
                    tag = "per_app_settings_item"
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Section: Tunnel Behavior
        item {
            SettingsCategoryHeader("Tunnel Configuration")
            SettingsCard {
                SettingsClickableItem(
                    title = "Proxy Payload Forwarder",
                    subtitle = "Dynamic ServerSocket with protect() and 200 validation",
                    icon = Icons.Default.Transform,
                    onClick = {
                        Toast.makeText(context, "Payload forwarder active on 127.0.0.1", Toast.LENGTH_SHORT).show()
                    },
                    tag = "forwarder_settings_item"
                )
                Divider(color = NavyCardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
                SettingsClickableItem(
                    title = "Keep-Alive & Timeout",
                    subtitle = "10s connection timeout with periodic WebSocket ping",
                    icon = Icons.Default.Timer,
                    onClick = {
                        Toast.makeText(context, "Keep-alive enabled", Toast.LENGTH_SHORT).show()
                    },
                    tag = "keepalive_settings_item"
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Section: About & Developer
        item {
            SettingsCategoryHeader("About & Developer")
            SettingsCard {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(SkyBluePrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = "Developer",
                                tint = SkyBluePrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Salah VPN",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Version 1.0.0 · Build 2026.10",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = NavyCardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "المطوّر:",
                        fontSize = 12.sp,
                        color = SkyBlueSecondary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "مطورين النت في العراق",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "تطبيق مخصص لدعم بروتوكولات VLESS وVMess وTrojan وShadowsocks مع معمارية Proxy + Payload المتطورة لتجاوز الحجب.",
                        fontSize = 12.sp,
                        color = TextTertiary,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }

    // DNS Selection Dialog
    if (showDnsDialog) {
        AlertDialog(
            onDismissRequest = { showDnsDialog = false },
            containerColor = NavySurface,
            title = {
                Text(
                    text = "Select DNS Server",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            },
            text = {
                Column {
                    dnsPresets.forEach { (name, ip) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.updateDns(ip)
                                    showDnsDialog = false
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(name, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                                Text(ip, fontSize = 12.sp, color = SkyBlueSecondary)
                            }
                            if (selectedDns == ip) {
                                Icon(Icons.Default.Check, contentDescription = "Selected", tint = SkyBluePrimary)
                            }
                        }
                        Divider(color = NavyCardBorder.copy(alpha = 0.3f), thickness = 0.5.dp)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Or custom DNS IP:", fontSize = 11.sp, color = TextSecondary)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = customDnsInput,
                        onValueChange = { customDnsInput = it },
                        placeholder = { Text("e.g. 1.0.0.1", fontSize = 12.sp, color = TextTertiary) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SkyBluePrimary,
                            unfocusedBorderColor = NavyCardBorder,
                            focusedContainerColor = NavyDarkBackground,
                            unfocusedContainerColor = NavyDarkBackground,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                if (customDnsInput.isNotBlank()) {
                    Button(
                        onClick = {
                            viewModel.updateDns(customDnsInput.trim())
                            showDnsDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SkyBluePrimary)
                    ) {
                        Text("Set Custom", color = NavyDarkBackground)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showDnsDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun SettingsCategoryHeader(title: String) {
    Text(
        text = title,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        color = SkyBlueSecondary,
        modifier = Modifier.padding(vertical = 6.dp)
    )
}

@Composable
private fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(NavySurface)
            .border(1.dp, NavyCardBorder, RoundedCornerShape(16.dp))
    ) {
        Column(content = content)
    }
}

@Composable
private fun SettingsClickableItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    tag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(14.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(NavySurfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = SkyBlueTertiary,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(1.dp))
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = TextTertiary,
            modifier = Modifier.size(18.dp)
        )
    }
}
