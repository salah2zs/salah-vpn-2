package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sky Blue bespoke palette for Salah VPN
val SkyBluePrimary = Color(0xFF00B0FF)
val SkyBlueSecondary = Color(0xFF40C4FF)
val SkyBlueTertiary = Color(0xFF80D8FF)
val SkyBlueVariant = Color(0xFF0288D1)
val SkyBlueDark = Color(0xFF01579B)

// Deep Navy OLED background
val NavyDarkBackground = Color(0xFF07111E)
val NavySurface = Color(0xFF0C1B2E)
val NavySurfaceVariant = Color(0xFF132742)
val NavyCardBorder = Color(0xFF1D3B63)

// Status colors
val StatusConnected = Color(0xFF00E676)
val StatusConnecting = Color(0xFFFFD600)
val StatusDisconnected = Color(0xFF78909C)
val StatusError = Color(0xFFFF5252)

// Text & Accent
val TextPrimary = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF8B9EB3)
val TextTertiary = Color(0xFF5B6E82)
val CyanAccent = Color(0xFF18FFFF)
