package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = SkyBluePrimary,
    onPrimary = NavyDarkBackground,
    primaryContainer = SkyBlueDark,
    onPrimaryContainer = SkyBlueTertiary,
    secondary = SkyBlueSecondary,
    onSecondary = NavyDarkBackground,
    secondaryContainer = NavySurfaceVariant,
    onSecondaryContainer = SkyBlueTertiary,
    tertiary = CyanAccent,
    onTertiary = NavyDarkBackground,
    background = NavyDarkBackground,
    onBackground = TextPrimary,
    surface = NavySurface,
    onSurface = TextPrimary,
    surfaceVariant = NavySurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = NavyCardBorder,
    error = StatusError,
    onError = Color.White
)

private val LightColorScheme = darkColorScheme(
    // Keep dark aesthetic as default for Salah VPN for high tech look
    primary = SkyBluePrimary,
    onPrimary = NavyDarkBackground,
    background = NavyDarkBackground,
    surface = NavySurface,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep bespoke Salah VPN brand sky blue identity
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
