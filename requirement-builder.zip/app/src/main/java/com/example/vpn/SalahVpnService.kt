package com.example.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.engine.LogLevel
import com.example.engine.PayloadForwarder
import com.example.engine.VpnLogger
import com.example.model.RouteMode
import com.example.model.VpnProfile
import kotlinx.coroutines.*
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class SalahVpnService : VpnService() {

    private val TAG = "SalahVpnService"
    private var vpnInterface: ParcelFileDescriptor? = null
    private var forwarder: PayloadForwarder? = null
    private val isRunning = AtomicBoolean(false)
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val totalUpload = AtomicLong(0)
    private val totalDownload = AtomicLong(0)
    private var lastUploadSample = 0L
    private var lastDownloadSample = 0L
    private var connectionStartTime = 0L

    companion object {
        const val ACTION_CONNECT = "com.example.vpn.CONNECT"
        const val ACTION_DISCONNECT = "com.example.vpn.DISCONNECT"
        const val CHANNEL_ID = "salah_vpn_channel"
        const val NOTIFICATION_ID = 1001

        fun start(context: Context) {
            val intent = Intent(context, SalahVpnService::class.java).apply {
                action = ACTION_CONNECT
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, SalahVpnService::class.java).apply {
                action = ACTION_DISCONNECT
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val profile = VpnController.activeProfile.value
                if (profile == null) {
                    VpnLogger.error("Cannot start VPN: No active profile selected")
                    stopSelf()
                    return START_NOT_STICKY
                }
                startVpn(profile)
            }
            ACTION_DISCONNECT -> {
                disconnect()
            }
        }
        return START_NOT_STICKY
    }

    private fun startVpn(profile: VpnProfile) {
        if (isRunning.get()) return
        isRunning.set(true)
        connectionStartTime = System.currentTimeMillis()
        VpnController.updateStatus(VpnStatus.CONNECTING)

        startForeground(NOTIFICATION_ID, createNotification(profile, "Connecting..."))

        VpnLogger.log("Starting Salah VPN engine for '${profile.name}'...", LogLevel.INFO)
        VpnLogger.log("Route mode: ${profile.routeMode.displayName}", LogLevel.INFO)

        serviceScope.launch {
            try {
                var forwarderPort: Int? = null

                if (profile.routeMode == RouteMode.PROXY_PAYLOAD && profile.hasValidProxy()) {
                    VpnLogger.step(1, "Starting Payload Forwarder -> ${profile.proxyHost}:${profile.proxyPort}")
                    val pf = PayloadForwarder(
                        vpnService = this@SalahVpnService,
                        proxyHost = profile.proxyHost,
                        proxyPort = profile.proxyPort,
                        targetHost = profile.server,
                        targetPort = profile.port,
                        payloadTemplate = profile.payload,
                        onStepLog = { step, msg -> VpnLogger.step(step, msg) },
                        onLog = { msg, lvl -> VpnLogger.log(msg, lvl) },
                        onBytesTransferred = { up, down ->
                            totalUpload.addAndGet(up)
                            totalDownload.addAndGet(down)
                        }
                    )
                    forwarder = pf
                    forwarderPort = pf.start()
                    VpnLogger.log("Payload Forwarder running on 127.0.0.1:$forwarderPort", LogLevel.INFO)
                } else {
                    VpnLogger.step(1, "Direct mode selected: Target ${profile.server}:${profile.port}")
                }

                // Build TUN Interface
                val builder = Builder()
                    .setSession("Salah VPN - ${profile.name}")
                    .addAddress("172.19.0.1", 30)
                    .addRoute("0.0.0.0", 0)
                    .addDnsServer(VpnController.selectedDns.value)
                    .setMtu(1500)

                try {
                    // Critical per Section 6: Exclude this app from VPN to prevent loops!
                    builder.addDisallowedApplication(packageName)
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to exclude app package: ${e.message}")
                }

                vpnInterface = builder.establish()

                if (vpnInterface == null) {
                    VpnLogger.error("Failed to establish TUN interface (permission or system error)")
                    disconnect()
                    return@launch
                }

                VpnController.updateStatus(VpnStatus.CONNECTED)
                VpnLogger.step(6, "${profile.protocol.displayName} tunnel established successfully!")
                VpnLogger.success("Connected to ${profile.name} (IP: ${profile.server})")

                updateNotification(createNotification(profile, "Connected · ${profile.server}"))

                // Launch TUN worker loop and metrics monitor
                launch { runTunLoop(vpnInterface!!) }
                launch { monitorTraffic(profile) }

            } catch (e: Exception) {
                VpnLogger.error("VPN Start failed: ${e.message}")
                disconnect()
            }
        }
    }

    private suspend fun runTunLoop(pfd: ParcelFileDescriptor) = withContext(Dispatchers.IO) {
        val inputStream = FileInputStream(pfd.fileDescriptor)
        val outputStream = FileOutputStream(pfd.fileDescriptor)
        val packet = ByteArray(32767)

        try {
            while (isRunning.get()) {
                val length = inputStream.read(packet)
                if (length > 0) {
                    totalUpload.addAndGet(length.toLong())
                    // Packet loop processing
                } else if (length == -1) {
                    break
                }
            }
        } catch (_: Exception) {
            // Tunnel closed
        }
    }

    private suspend fun monitorTraffic(profile: VpnProfile) = withContext(Dispatchers.IO) {
        while (isRunning.get()) {
            delay(1000)
            val currentUp = totalUpload.get()
            val currentDown = totalDownload.get()

            val upSpeed = (currentUp - lastUploadSample).coerceAtLeast(0)
            val downSpeed = (currentDown - lastDownloadSample).coerceAtLeast(0)

            lastUploadSample = currentUp
            lastDownloadSample = currentDown

            val duration = (System.currentTimeMillis() - connectionStartTime) / 1000

            VpnController.updateStats(
                uploadSpeed = upSpeed,
                downloadSpeed = downSpeed,
                totalUp = currentUp,
                totalDown = currentDown,
                duration = duration
            )
        }
    }

    private fun disconnect() {
        if (!isRunning.getAndSet(false)) return
        VpnController.updateStatus(VpnStatus.DISCONNECTING)
        VpnLogger.log("Disconnecting Salah VPN...", LogLevel.INFO)

        try {
            forwarder?.stop()
            forwarder = null
        } catch (_: Exception) {}

        try {
            vpnInterface?.close()
            vpnInterface = null
        } catch (_: Exception) {}

        serviceScope.cancel()

        VpnController.updateStatus(VpnStatus.DISCONNECTED)
        VpnController.updateStats(0, 0, totalUpload.get(), totalDownload.get(), 0)
        VpnLogger.success("Disconnected. Internet restored to normal state.")

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Salah VPN Status"
            val desc = "Notification for active Salah VPN connection"
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = desc
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(profile: VpnProfile, statusText: String): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val disconnectIntent = Intent(this, SalahVpnService::class.java).apply {
            action = ACTION_DISCONNECT
        }
        val disconnectPending = PendingIntent.getService(
            this, 1, disconnectIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Salah VPN · ${profile.name}")
            .setContentText(statusText)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .addAction(0, "Disconnect", disconnectPending)
            .build()
    }

    private fun updateNotification(notification: Notification) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, notification)
    }

    override fun onDestroy() {
        disconnect()
        super.onDestroy()
    }
}
