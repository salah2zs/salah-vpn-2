package com.example.vpn

import com.example.model.VpnProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class VpnStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    DISCONNECTING,
    ERROR
}

data class VpnStatistics(
    val uploadSpeedBps: Long = 0,
    val downloadSpeedBps: Long = 0,
    val totalUploadBytes: Long = 0,
    val totalDownloadBytes: Long = 0,
    val connectionDurationSeconds: Long = 0
)

object VpnController {

    private val _status = MutableStateFlow(VpnStatus.DISCONNECTED)
    val status: StateFlow<VpnStatus> = _status.asStateFlow()

    private val _activeProfile = MutableStateFlow<VpnProfile?>(null)
    val activeProfile: StateFlow<VpnProfile?> = _activeProfile.asStateFlow()

    private val _stats = MutableStateFlow(VpnStatistics())
    val stats: StateFlow<VpnStatistics> = _stats.asStateFlow()

    private val _selectedDns = MutableStateFlow("8.8.8.8")
    val selectedDns: StateFlow<String> = _selectedDns.asStateFlow()

    fun updateStatus(newStatus: VpnStatus) {
        _status.value = newStatus
    }

    fun setActiveProfile(profile: VpnProfile?) {
        _activeProfile.value = profile
    }

    fun updateStats(uploadSpeed: Long, downloadSpeed: Long, totalUp: Long, totalDown: Long, duration: Long) {
        _stats.value = VpnStatistics(
            uploadSpeedBps = uploadSpeed,
            downloadSpeedBps = downloadSpeed,
            totalUploadBytes = totalUp,
            totalDownloadBytes = totalDown,
            connectionDurationSeconds = duration
        )
    }

    fun setDns(dns: String) {
        _selectedDns.value = dns
    }
}
