package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.ConfigGenerator
import com.example.engine.ConfigParser
import com.example.engine.PayloadFormatter
import com.example.model.Protocol
import com.example.model.RouteMode
import com.example.model.VpnProfile
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Salah VPN", appName)
    }

    @Test
    fun `test payload formatting with variables`() {
        val raw = "CONNECT [host_port] HTTP/1.1[crlf]Host: [host][crlf]Port: [port][crlf][crlf]"
        val formatted = PayloadFormatter.format(raw, "my.server.com", 443)
        val expected = "CONNECT my.server.com:443 HTTP/1.1\r\nHost: my.server.com\r\nPort: 443\r\n\r\n"
        assertEquals(expected, formatted)
    }

    @Test
    fun `test payload split feature`() {
        val payloadWithSplit = "CONNECT [host_port] HTTP/1.1[crlf][split]Host: [host][crlf][crlf]"
        val segments = PayloadFormatter.splitPayload(payloadWithSplit)
        assertEquals(2, segments.size)
        assertEquals("CONNECT [host_port] HTTP/1.1[crlf]", segments[0])
        assertEquals("Host: [host][crlf][crlf]", segments[1])
    }

    @Test
    fun `test sing box outbound config generation with proxy payload`() {
        val profile = VpnProfile(
            name = "Test VLESS",
            protocol = Protocol.VLESS,
            server = "target.domain.com",
            port = 443,
            authKey = "uuid-1234-abcd",
            sni = "target.domain.com",
            path = "/vless-ws",
            headerHost = "target.domain.com",
            routeMode = RouteMode.PROXY_PAYLOAD,
            proxyHost = "1.2.3.4",
            proxyPort = 8080
        )

        val outbound = ConfigGenerator.buildOutbound(profile, localForwarderPort = 10808)
        assertEquals("vless", outbound.getString("type"))
        assertEquals("127.0.0.1", outbound.getString("server"))
        assertEquals(10808, outbound.getInt("server_port"))
        assertEquals("uuid-1234-abcd", outbound.getString("uuid"))
        assertTrue(outbound.has("tls"))
        assertEquals("target.domain.com", outbound.getJSONObject("tls").getString("server_name"))
        assertTrue(outbound.has("transport"))
        assertEquals("/vless-ws", outbound.getJSONObject("transport").getString("path"))
    }

    @Test
    fun `test sz encrypted config roundtrip`() {
        val profile = VpnProfile(
            name = "VIP Baghdad Server",
            protocol = Protocol.VLESS,
            server = "iq.vpn.net",
            port = 443,
            authKey = "test-uuid-baghdad",
            proxyHost = "185.199.108.153",
            proxyPort = 8080,
            payload = "CONNECT [host_port] HTTP/1.1[crlf]Host: [host][crlf][crlf]",
            routeMode = RouteMode.PROXY_PAYLOAD
        )

        val szString = ConfigParser.exportToSz(profile)
        assertTrue(szString.startsWith("sz://"))

        val imported = ConfigParser.importFromSz(szString)
        assertNotNull(imported)
        assertEquals("VIP Baghdad Server", imported!!.name)
        assertEquals("iq.vpn.net", imported.server)
        assertEquals(443, imported.port)
        assertEquals("test-uuid-baghdad", imported.authKey)
        assertEquals("185.199.108.153", imported.proxyHost)
        assertEquals(8080, imported.proxyPort)
        assertEquals(RouteMode.PROXY_PAYLOAD, imported.routeMode)
    }

    @Test
    fun `test vless uri parsing`() {
        val uri = "vless://b831381d-6324-4d53-ad4f-8cda48b30811@104.21.23.45:443?type=ws&security=tls&sni=example.com&host=example.com&path=%2Fvless-ws#My%20VLESS%20Node"
        val parsed = ConfigParser.parseUri(uri)
        assertNotNull(parsed)
        assertEquals("My VLESS Node", parsed!!.name)
        assertEquals("104.21.23.45", parsed.server)
        assertEquals(443, parsed.port)
        assertEquals("b831381d-6324-4d53-ad4f-8cda48b30811", parsed.authKey)
        assertEquals("example.com", parsed.sni)
        assertEquals("example.com", parsed.headerHost)
        assertEquals("/vless-ws", parsed.path)
    }
}
