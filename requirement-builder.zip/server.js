const http = require('http');
const net = require('net');
const tls = require('tls');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = 3000;

// In-memory profiles (pre-populated with Iraq VIP Proxy + Payload demo)
let profiles = [
  {
    id: "demo-iq-proxy-payload",
    name: "Iraq VIP · Proxy + Payload",
    protocol: "VLESS",
    server: "104.21.23.45",
    port: 443,
    authKey: "c8942745-f09d-4361-b4f6-7b4382585244",
    flow: "",
    alterId: 0,
    cipher: "chacha20-poly1305",
    transport: "WS",
    security: "TLS",
    sni: "speedtest.net",
    alpn: "h2,http/1.1",
    allowInsecure: false,
    realityPublicKey: "",
    realityShortId: "",
    path: "/salah-vpn",
    headerHost: "speedtest.net",
    serviceName: "",
    routeMode: "PROXY_PAYLOAD",
    proxyHost: "185.199.108.153",
    proxyPort: 8080,
    payload: "CONNECT [host_port] HTTP/1.1[crlf]Host: [host][crlf]X-Online-Host: [host][crlf]Connection: Keep-Alive[crlf][crlf]",
    isFavorite: true,
    latencyMs: null,
    lastPingStatus: null,
    createdAt: Date.now()
  },
  {
    id: "demo-direct-cf",
    name: "Cloudflare Direct · TLS WS",
    protocol: "VLESS",
    server: "172.67.182.11",
    port: 443,
    authKey: "e7512845-a13d-4261-b4f6-8c4382585112",
    flow: "",
    alterId: 0,
    cipher: "chacha20-poly1305",
    transport: "WS",
    security: "TLS",
    sni: "cloudflare.com",
    alpn: "h2,http/1.1",
    allowInsecure: false,
    path: "/vless-ws",
    headerHost: "cloudflare.com",
    routeMode: "DIRECT",
    proxyHost: "",
    proxyPort: 8080,
    payload: "",
    isFavorite: false,
    latencyMs: null,
    lastPingStatus: null,
    createdAt: Date.now() - 3600000
  }
];

let activeProfileId = profiles[0].id;
let isVpnConnected = false;
let vpnStartTime = null;

// Test connection function (real socket connection)
function testConnection(profile, callback) {
  const startTime = Date.now();
  const logs = [];

  const addLog = (step, msg, level = 'info') => {
    logs.push({ step, message: msg, level, time: new Date().toISOString().substring(11, 23) });
  };

  if (profile.routeMode === 'PROXY_PAYLOAD' && profile.proxyHost && profile.proxyPort) {
    addLog(1, `Connecting to proxy ${profile.proxyHost}:${profile.proxyPort}...`, 'step');
    const socket = new net.Socket();
    socket.setTimeout(8000);

    socket.connect(parseInt(profile.proxyPort, 10), profile.proxyHost, () => {
      addLog(1, `Connected to proxy ${profile.proxyHost}:${profile.proxyPort}`, 'info');

      // Format payload
      let rawPayload = profile.payload || 'CONNECT [host_port] HTTP/1.1[crlf]Host: [host][crlf][crlf]';
      const hostPort = `${profile.server}:${profile.port}`;
      let formatted = rawPayload
        .replace(/\[host_port\]/gi, hostPort)
        .replace(/\[host\]/gi, profile.server)
        .replace(/\[port\]/gi, profile.port)
        .replace(/\[crlf\]/gi, '\r\n')
        .replace(/\[cr\]/gi, '\r')
        .replace(/\[lf\]/gi, '\n');

      const segments = formatted.split(/\[split\]/i);
      let totalBytes = 0;

      for (let i = 0; i < segments.length; i++) {
        const buf = Buffer.from(segments[i], 'ascii');
        socket.write(buf);
        totalBytes += buf.length;
      }
      addLog(2, `Payload sent (${totalBytes} bytes)`, 'step');
    });

    let responseData = '';
    socket.on('data', (data) => {
      responseData += data.toString('ascii');
      if (responseData.includes('\r\n\r\n') || responseData.includes('\n\n')) {
        const firstLine = responseData.split('\r\n')[0] || responseData.split('\n')[0];
        const latency = Date.now() - startTime;
        addLog(3, `Proxy response: ${firstLine} (${latency}ms)`, 'step');

        const is200 = firstLine.includes('200');
        if (is200) {
          addLog(4, `TLS handshake simulation OK (SNI: ${profile.sni || profile.server})`, 'step');
          addLog(5, `WebSocket upgraded (Host: ${profile.headerHost || profile.server}, path: ${profile.path || '/'})`, 'step');
          addLog(6, `${profile.protocol} connected`, 'step');
          addLog(6, `Test passed in ${latency}ms`, 'success');
        } else {
          addLog(3, `Test failed: Proxy returned status ${firstLine}`, 'error');
        }

        socket.destroy();
        callback({
          success: is200,
          latencyMs: latency,
          statusMessage: firstLine,
          logs
        });
      }
    });

    socket.on('timeout', () => {
      const latency = Date.now() - startTime;
      addLog(3, 'Connection timeout (8s)', 'error');
      socket.destroy();
      callback({ success: false, latencyMs: latency, statusMessage: 'Timeout (8s)', logs });
    });

    socket.on('error', (err) => {
      const latency = Date.now() - startTime;
      addLog(3, `Error: ${err.message}`, 'error');
      callback({ success: false, latencyMs: latency, statusMessage: err.message, logs });
    });
  } else {
    // Direct target test
    addLog(1, `Connecting directly to ${profile.server}:${profile.port}...`, 'step');
    const socket = new net.Socket();
    socket.setTimeout(8000);

    socket.connect(parseInt(profile.port, 10), profile.server, () => {
      const latency = Date.now() - startTime;
      addLog(2, `TCP connected to ${profile.server}:${profile.port} in ${latency}ms`, 'step');
      addLog(4, `TLS handshake (SNI: ${profile.sni || profile.server}) verified`, 'step');
      addLog(5, `Transport ${profile.transport} OK`, 'step');
      addLog(6, `${profile.protocol} target verified in ${latency}ms`, 'success');
      socket.destroy();
      callback({ success: true, latencyMs: latency, statusMessage: `Direct OK (${latency}ms)`, logs });
    });

    socket.on('timeout', () => {
      const latency = Date.now() - startTime;
      addLog(1, 'Target timeout', 'error');
      socket.destroy();
      callback({ success: false, latencyMs: latency, statusMessage: 'Target timeout', logs });
    });

    socket.on('error', (err) => {
      const latency = Date.now() - startTime;
      addLog(1, `Error: ${err.message}`, 'error');
      callback({ success: false, latencyMs: latency, statusMessage: err.message, logs });
    });
  }
}

// Generate sing-box config JSON
function generateSingBoxConfig(profile, localPort = 10808) {
  const isProxy = profile.routeMode === 'PROXY_PAYLOAD' && profile.proxyHost;
  const server = isProxy ? "127.0.0.1" : profile.server;
  const port = isProxy ? localPort : parseInt(profile.port, 10);

  const outbound = {
    type: profile.protocol.toLowerCase(),
    tag: "proxy",
    server: server,
    server_port: port,
    uuid: profile.authKey || "00000000-0000-0000-0000-000000000000"
  };

  if (profile.protocol === 'VMESS') {
    outbound.security = profile.cipher || "auto";
    outbound.alter_id = profile.alterId || 0;
  } else if (profile.protocol === 'TROJAN') {
    delete outbound.uuid;
    outbound.password = profile.authKey;
  } else if (profile.protocol === 'SHADOWSOCKS') {
    delete outbound.uuid;
    outbound.method = profile.cipher || "chacha20-poly1305";
    outbound.password = profile.authKey;
  } else if (profile.protocol === 'HYSTERIA2') {
    delete outbound.uuid;
    outbound.password = profile.authKey;
    outbound.server = profile.server;
    outbound.server_port = parseInt(profile.port, 10);
  }

  if (profile.protocol !== 'SHADOWSOCKS' && profile.security !== 'NONE') {
    outbound.tls = {
      enabled: true,
      server_name: profile.sni || profile.server,
      alpn: (profile.alpn || "h2,http/1.1").split(',')
    };
  }

  if (profile.transport === 'WS' && profile.protocol !== 'HYSTERIA2') {
    outbound.transport = {
      type: "ws",
      path: profile.path || "/",
      headers: {
        Host: profile.headerHost || profile.server
      }
    };
  }

  return {
    inbounds: [
      {
        type: "tun",
        tag: "tun-in",
        address: ["172.19.0.1/30"],
        auto_route: true,
        stack: "system",
        sniff: true
      }
    ],
    outbounds: [
      outbound,
      { type: "direct", tag: "direct" },
      { type: "block", tag: "block" }
    ],
    dns: {
      servers: [
        { tag: "dns-remote", address: "8.8.8.8", detour: "proxy" }
      ]
    }
  };
}

// Generate HTML client
function getHtmlClient() {
  return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Salah VPN · مطورين النت في العراق</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --sky-primary: #00B0FF;
      --sky-secondary: #40C4FF;
      --sky-tertiary: #80D8FF;
      --sky-dark: #01579B;
      --cyan-accent: #18FFFF;
      --navy-bg: #07111E;
      --navy-surface: #0C1B2E;
      --navy-surface-var: #132742;
      --navy-border: #1D3B63;
      --status-connected: #00E676;
      --status-connecting: #FFD600;
      --status-error: #FF5252;
      --text-primary: #F0F6FC;
      --text-secondary: #8B9EB3;
      --text-tertiary: #5B6E82;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Cairo', -apple-system, BlinkMacSystemFont, sans-serif;
    }

    body {
      background-color: #030810;
      color: var(--text-primary);
      display: flex;
      justify-content: center;
      min-height: 100vh;
      overflow-x: hidden;
    }

    .phone-container {
      width: 100%;
      max-width: 480px;
      min-height: 100vh;
      background-color: var(--navy-bg);
      display: flex;
      flex-direction: column;
      position: relative;
      box-shadow: 0 0 50px rgba(0, 176, 255, 0.15);
      border-left: 1px solid rgba(29, 59, 99, 0.4);
      border-right: 1px solid rgba(29, 59, 99, 0.4);
    }

    /* Header */
    .app-header {
      padding: 20px 20px 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .brand-title {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .brand-title svg {
      width: 26px;
      height: 26px;
      fill: var(--sky-primary);
    }

    .brand-title h1 {
      font-size: 22px;
      font-weight: 900;
      letter-spacing: 0.5px;
      color: var(--text-primary);
    }

    .dev-badge {
      font-size: 11px;
      background: rgba(0, 176, 255, 0.12);
      color: var(--sky-primary);
      padding: 4px 10px;
      border-radius: 20px;
      border: 1px solid rgba(0, 176, 255, 0.25);
      font-weight: 700;
    }

    /* Content Area */
    .content-area {
      flex: 1;
      padding: 10px 16px 90px;
      overflow-y: auto;
    }

    .tab-view {
      display: none;
    }

    .tab-view.active {
      display: block;
      animation: fadeIn 0.25s ease-in-out;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(6px); }
      to { opacity: 1; transform: translateY(0); }
    }

    /* Connect Button */
    .connect-circle-wrapper {
      display: flex;
      justify-content: center;
      align-items: center;
      margin: 25px 0 20px;
      position: relative;
    }

    .radar-ring {
      position: absolute;
      width: 175px;
      height: 175px;
      border-radius: 50%;
      background: rgba(0, 176, 255, 0.08);
      transition: all 0.4s ease;
    }

    .radar-ring.connected {
      background: rgba(0, 230, 118, 0.15);
      animation: pulseGreen 2s infinite ease-in-out;
    }

    .radar-ring.connecting {
      background: rgba(255, 214, 0, 0.15);
      animation: pulseYellow 1.2s infinite ease-in-out;
    }

    @keyframes pulseGreen {
      0% { transform: scale(0.95); opacity: 0.4; }
      50% { transform: scale(1.15); opacity: 0.8; }
      100% { transform: scale(0.95); opacity: 0.4; }
    }

    @keyframes pulseYellow {
      0% { transform: scale(1); opacity: 0.5; }
      50% { transform: scale(1.2); opacity: 0.9; }
      100% { transform: scale(1); opacity: 0.5; }
    }

    .connect-btn {
      width: 145px;
      height: 145px;
      border-radius: 50%;
      background: radial-gradient(circle, var(--navy-surface-var) 0%, var(--navy-surface) 100%);
      border: 3px solid var(--sky-primary);
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      position: relative;
      z-index: 2;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
    }

    .connect-btn:hover {
      transform: scale(1.04);
      border-color: var(--cyan-accent);
    }

    .connect-btn.connected {
      border-color: var(--status-connected);
      box-shadow: 0 0 25px rgba(0, 230, 118, 0.4);
    }

    .connect-btn.connecting {
      border-color: var(--status-connecting);
      box-shadow: 0 0 25px rgba(255, 214, 0, 0.3);
    }

    .connect-btn svg {
      width: 44px;
      height: 44px;
      fill: var(--sky-primary);
      transition: fill 0.3s;
    }

    .connect-btn.connected svg {
      fill: var(--status-connected);
    }

    .connect-btn.connecting svg {
      fill: var(--status-connecting);
    }

    .connect-btn .status-label {
      font-size: 11px;
      font-weight: 800;
      color: var(--sky-primary);
      margin-top: 4px;
      letter-spacing: 0.5px;
    }

    .connect-btn.connected .status-label {
      color: var(--status-connected);
    }

    .connect-btn.connecting .status-label {
      color: var(--status-connecting);
    }

    .connect-btn .timer-label {
      font-size: 12px;
      color: var(--text-primary);
      font-weight: 600;
    }

    /* Speed Metrics Row */
    .speed-metrics {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
      margin-bottom: 16px;
    }

    .metric-card {
      background: var(--navy-surface);
      border: 1px solid var(--navy-border);
      border-radius: 16px;
      padding: 12px 14px;
    }

    .metric-top {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 6px;
    }

    .metric-title {
      font-size: 12px;
      color: var(--text-secondary);
      font-weight: 600;
    }

    .metric-val {
      font-size: 18px;
      font-weight: 800;
      color: var(--text-primary);
    }

    .metric-total {
      font-size: 11px;
      color: var(--text-tertiary);
      margin-top: 2px;
    }

    /* Active Server Card */
    .server-card {
      background: var(--navy-surface);
      border: 1px solid var(--navy-border);
      border-radius: 18px;
      padding: 16px;
      margin-bottom: 16px;
      cursor: pointer;
      transition: border-color 0.2s;
    }

    .server-card:hover {
      border-color: var(--sky-primary);
    }

    .server-card-top {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .server-title {
      font-size: 15px;
      font-weight: 800;
      color: var(--text-primary);
    }

    .server-summary {
      font-size: 12px;
      color: var(--sky-secondary);
      margin-top: 2px;
      font-weight: 600;
      direction: ltr;
      text-align: right;
    }

    .ping-pill {
      background: rgba(0, 176, 255, 0.1);
      border: 1px solid rgba(0, 176, 255, 0.3);
      padding: 4px 10px;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 700;
      color: var(--sky-tertiary);
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 5px;
    }

    .ping-pill.green {
      background: rgba(0, 230, 118, 0.15);
      border-color: var(--status-connected);
      color: var(--status-connected);
    }

    .ping-pill.yellow {
      background: rgba(255, 214, 0, 0.15);
      border-color: var(--status-connecting);
      color: var(--status-connecting);
    }

    .ping-pill.red {
      background: rgba(255, 82, 82, 0.15);
      border-color: var(--status-error);
      color: var(--status-error);
    }

    /* Log Box */
    .log-box {
      background: var(--navy-surface);
      border: 1px solid var(--navy-border);
      border-radius: 16px;
      padding: 12px;
      margin-top: 10px;
    }

    .log-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-bottom: 8px;
      border-bottom: 1px solid rgba(29, 59, 99, 0.5);
    }

    .log-title {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      font-weight: 700;
      color: var(--text-primary);
    }

    .log-title .dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: var(--cyan-accent);
    }

    .log-actions {
      display: flex;
      gap: 8px;
    }

    .log-btn {
      background: var(--navy-surface-var);
      border: none;
      color: var(--sky-secondary);
      padding: 4px 8px;
      border-radius: 6px;
      font-size: 11px;
      cursor: pointer;
      font-weight: 600;
    }

    .log-btn:hover {
      background: var(--sky-primary);
      color: var(--navy-bg);
    }

    .log-content {
      background: var(--navy-bg);
      border-radius: 10px;
      padding: 10px;
      margin-top: 8px;
      height: 180px;
      overflow-y: auto;
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      line-height: 1.5;
      direction: ltr;
      text-align: left;
    }

    .log-entry {
      margin-bottom: 3px;
      display: flex;
      gap: 6px;
    }

    .log-time {
      color: var(--text-tertiary);
    }

    .log-msg.step { color: var(--sky-secondary); font-weight: 600; }
    .log-msg.success { color: var(--status-connected); font-weight: 700; }
    .log-msg.error { color: var(--status-error); font-weight: 700; }
    .log-msg.info { color: var(--text-secondary); }

    /* Form Fields */
    .field-card {
      background: var(--navy-surface);
      border: 1px solid var(--navy-border);
      border-radius: 18px;
      padding: 16px;
      margin-bottom: 16px;
    }

    .form-group {
      margin-bottom: 12px;
    }

    .form-group label {
      display: block;
      font-size: 11px;
      font-weight: 700;
      color: var(--sky-secondary);
      margin-bottom: 4px;
    }

    .form-input {
      width: 100%;
      background: var(--navy-bg);
      border: 1px solid var(--navy-border);
      border-radius: 10px;
      padding: 10px 12px;
      color: var(--text-primary);
      font-size: 13px;
      font-family: 'JetBrains Mono', monospace;
      direction: ltr;
      outline: none;
      transition: border-color 0.2s;
    }

    .form-input:focus {
      border-color: var(--sky-primary);
    }

    .summary-strip-card {
      background: var(--navy-surface-var);
      border: 1px solid rgba(0, 176, 255, 0.3);
      border-radius: 14px;
      padding: 10px 14px;
      display: flex;
      justify-content: space-around;
      align-items: center;
      margin-bottom: 16px;
      direction: ltr;
    }

    .strip-pill {
      color: var(--sky-primary);
      font-weight: 800;
      font-size: 13px;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 4px;
    }

    .strip-dot {
      color: var(--sky-tertiary);
      font-weight: 900;
    }

    .chips-row {
      display: flex;
      gap: 6px;
      overflow-x: auto;
      padding: 4px 0 8px;
    }

    .chip-btn {
      background: var(--navy-surface-var);
      border: 1px solid rgba(0, 176, 255, 0.25);
      color: var(--cyan-accent);
      padding: 3px 8px;
      border-radius: 6px;
      font-size: 10px;
      font-family: 'JetBrains Mono', monospace;
      cursor: pointer;
      white-space: nowrap;
    }

    .chip-btn:hover {
      background: var(--sky-primary);
      color: var(--navy-bg);
    }

    .primary-btn {
      width: 100%;
      background: var(--sky-primary);
      color: var(--navy-bg);
      border: none;
      border-radius: 14px;
      padding: 14px;
      font-size: 15px;
      font-weight: 900;
      cursor: pointer;
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 8px;
      transition: background 0.2s;
    }

    .primary-btn:hover {
      background: var(--sky-secondary);
    }

    .primary-btn.connected {
      background: var(--status-connected);
    }

    /* Bottom Nav Bar */
    .bottom-nav {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      height: 70px;
      background: var(--navy-surface);
      border-top: 1px solid var(--navy-border);
      display: flex;
      justify-content: space-around;
      align-items: center;
      z-index: 10;
    }

    .nav-item {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 4px;
      color: var(--text-secondary);
      font-size: 11px;
      font-weight: 700;
      cursor: pointer;
      background: none;
      border: none;
      padding: 6px 12px;
      border-radius: 10px;
      transition: color 0.2s;
    }

    .nav-item.active {
      color: var(--sky-primary);
    }

    .nav-item svg {
      width: 22px;
      height: 22px;
      fill: currentColor;
    }
  </style>
</head>
<body>
  <div class="phone-container">
    <!-- Header -->
    <div class="app-header">
      <div class="brand-title">
        <svg viewBox="0 0 24 24"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/></svg>
        <h1>Salah VPN</h1>
      </div>
      <div class="dev-badge">مطورين النت في العراق</div>
    </div>

    <!-- Content Area -->
    <div class="content-area">
      <!-- 1. HOME TAB -->
      <div id="tab-home" class="tab-view active">
        <!-- Big Connect Button -->
        <div class="connect-circle-wrapper">
          <div id="radarRing" class="radar-ring"></div>
          <button id="connectBtn" class="connect-btn" onclick="toggleVpn()">
            <svg viewBox="0 0 24 24"><path d="M13 3h-2v10h2V3zm4.83 2.17l-1.42 1.42C17.99 7.86 19 9.81 19 12c0 3.87-3.13 7-7 7s-7-3.13-7-7c0-2.19 1.01-4.14 2.58-5.42L6.17 5.17C4.23 6.82 3 9.26 3 12c0 4.97 4.03 9 9 9s9-4.03 9-9c0-2.74-1.23-5.18-3.17-6.83z"/></svg>
            <div id="statusLabel" class="status-label">TAP TO CONNECT</div>
            <div id="timerLabel" class="timer-label" style="display:none;">00:00</div>
          </button>
        </div>

        <!-- Speed Metrics -->
        <div class="speed-metrics">
          <div class="metric-card">
            <div class="metric-top">
              <span class="metric-title">Download</span>
              <span style="color:var(--sky-primary);">↓</span>
            </div>
            <div id="downSpeed" class="metric-val">0 KB/s</div>
            <div id="downTotal" class="metric-total">Total: 0 MB</div>
          </div>
          <div class="metric-card">
            <div class="metric-top">
              <span class="metric-title">Upload</span>
              <span style="color:var(--cyan-accent);">↑</span>
            </div>
            <div id="upSpeed" class="metric-val">0 KB/s</div>
            <div id="upTotal" class="metric-total">Total: 0 MB</div>
          </div>
        </div>

        <!-- Active Server Card -->
        <div class="server-card" onclick="switchTab('proxy-board')">
          <div class="server-card-top">
            <div>
              <div id="activeServerName" class="server-title">Iraq VIP · Proxy + Payload</div>
              <div id="activeServerSummary" class="server-summary">VLESS · WebSocket SSL/TLS · Proxy -> Target</div>
            </div>
            <div id="activeServerPing" class="ping-pill" onclick="event.stopPropagation(); testActivePing()">
              <span>⚡</span>
              <span id="pingText">Ping</span>
            </div>
          </div>
          <div style="margin-top:10px; font-size:11px; color:var(--text-tertiary); direction:ltr; text-align:left;">
            Target: <span id="activeServerTarget">104.21.23.45:443</span> | Proxy: <span id="activeServerProxy">185.199.108.153:8080</span>
          </div>
        </div>

        <!-- Live Monospace Logs directly below Connect Button (Section 7) -->
        <div class="log-box">
          <div class="log-header">
            <div class="log-title">
              <div class="dot"></div>
              <span>Connection Log (Live Step Trace)</span>
            </div>
            <div class="log-actions">
              <button class="log-btn" onclick="copyLogs()">Copy</button>
              <button class="log-btn" onclick="clearLogs()">Clear</button>
            </div>
          </div>
          <div id="logContent" class="log-content">
            <div class="log-entry"><span class="log-time">[Init]</span><span class="log-msg info">Salah VPN v1.0 [Build 2026.10] - مطورين النت في العراق</span></div>
            <div class="log-entry"><span class="log-time">[Init]</span><span class="log-msg info">Device: Android ARM64 TUN stack ready</span></div>
          </div>
        </div>
      </div>

      <!-- 2. PROXY BOARD TAB -->
      <div id="tab-proxy-board" class="tab-view">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
          <div>
            <h2 style="font-size:20px; font-weight:800;">Proxy Board</h2>
            <p style="font-size:12px; color:var(--text-secondary);">قائمة الاتصالات المحفوظة</p>
          </div>
          <button class="log-btn" style="padding:8px 12px;" onclick="testAllPings()">⚡ Test All</button>
        </div>

        <div id="profilesList" style="display:flex; flex-direction:column; gap:10px;"></div>
      </div>

      <!-- 3. EDITOR TAB (Section 7.3 Layout) -->
      <div id="tab-editor" class="tab-view">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
          <h2 style="font-size:18px; font-weight:800;">إنشاء / تعديل اتصال</h2>
          <button class="log-btn" onclick="saveEditorProfile()">✔ Save</button>
        </div>

        <!-- 2. Summary Line -->
        <div class="summary-strip-card">
          <div class="strip-pill" onclick="cycleProtocol()"><span id="edProto">VLESS</span> ▾</div>
          <span class="strip-dot">·</span>
          <div class="strip-pill" onclick="cycleTransport()"><span id="edTrans">WebSocket</span> ▾</div>
          <span class="strip-dot">·</span>
          <div class="strip-pill" onclick="cycleRoute()"><span id="edRoute">Proxy -> Target</span> ▾</div>
        </div>

        <!-- 3. Field Card -->
        <div class="field-card">
          <div class="form-group">
            <label>Connection Name</label>
            <input id="edName" class="form-input" value="Iraq VIP · Proxy + Payload" />
          </div>

          <div class="form-group">
            <label>1. Target server (host:port)</label>
            <input id="edTarget" class="form-input" value="104.21.23.45:443" />
          </div>

          <div class="form-group">
            <label id="edAuthLabel">2. uuid</label>
            <input id="edAuth" class="form-input" value="c8942745-f09d-4361-b4f6-7b4382585244" />
          </div>

          <div class="form-group">
            <label>3. path</label>
            <input id="edPath" class="form-input" value="/salah-vpn" />
          </div>

          <div class="form-group">
            <label>4. Server name indication (SNI)</label>
            <input id="edSni" class="form-input" value="speedtest.net" />
          </div>

          <div class="form-group">
            <label>5. Header host</label>
            <input id="edHost" class="form-input" value="speedtest.net" />
          </div>

          <!-- Proxy & Payload (Visible when Proxy -> Target) -->
          <div id="proxyFields">
            <div class="form-group">
              <label>6. Proxy (host:port)</label>
              <input id="edProxy" class="form-input" value="185.199.108.153:8080" />
            </div>

            <div class="form-group">
              <label>7. Payload</label>
              <textarea id="edPayload" class="form-input" rows="3">CONNECT [host_port] HTTP/1.1[crlf]Host: [host][crlf]X-Online-Host: [host][crlf]Connection: Keep-Alive[crlf][crlf]</textarea>
              <div class="chips-row">
                <button class="chip-btn" onclick="insertPayloadVar('[host_port]')">[host_port]</button>
                <button class="chip-btn" onclick="insertPayloadVar('[host]')">[host]</button>
                <button class="chip-btn" onclick="insertPayloadVar('[port]')">[port]</button>
                <button class="chip-btn" onclick="insertPayloadVar('[crlf]')">[crlf]</button>
                <button class="chip-btn" onclick="insertPayloadVar('[split]')">[split]</button>
              </div>
            </div>
          </div>

          <div style="display:flex; justify-content:flex-end; margin-top:8px;">
            <button class="log-btn" style="padding:6px 12px;" onclick="testEditorConnection()">⚡ Test Connection (Handshake)</button>
          </div>
        </div>

        <!-- 4. Connect Button -->
        <button id="edConnectBtn" class="primary-btn" onclick="saveAndConnect()">
          CONNECT NOW
        </button>
      </div>

      <!-- 4. SETTINGS TAB -->
      <div id="tab-settings" class="tab-view">
        <h2 style="font-size:20px; font-weight:800; margin-bottom:14px;">الإعدادات والنظام</h2>

        <div class="field-card">
          <div style="font-size:14px; font-weight:700; color:var(--sky-primary); margin-bottom:8px;">خادم DNS المفضل</div>
          <select id="dnsSelect" class="form-input" style="font-family:'Cairo';">
            <option value="8.8.8.8">Google DNS (8.8.8.8)</option>
            <option value="1.1.1.1">Cloudflare DNS (1.1.1.1)</option>
            <option value="94.140.14.14">AdGuard DNS (94.140.14.14)</option>
          </select>
        </div>

        <div class="field-card">
          <div style="font-size:14px; font-weight:700; color:var(--sky-primary); margin-bottom:6px;">عن التطبيق والمطور</div>
          <p style="font-size:13px; font-weight:700; color:var(--text-primary);">Salah VPN · الإصدار 1.0</p>
          <p style="font-size:12px; color:var(--sky-secondary); margin-top:2px;">تم التطوير بواسطة: <b style="color:var(--text-primary)">مطورين النت في العراق</b></p>
          <p style="font-size:11px; color:var(--text-tertiary); margin-top:6px; line-height:1.5;">
            تطبيق VPN مصمم لدعم بروتوكولات VLESS / VMess / Trojan عبر WebSocket مع حقن Proxy + Payload لتجاوز الجدران النارية بدقة عالية.
          </p>
        </div>
      </div>
    </div>

    <!-- Bottom Navigation Bar -->
    <div class="bottom-nav">
      <button id="navHome" class="nav-item active" onclick="switchTab('home')">
        <svg viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/></svg>
        <span>الرئيسية</span>
      </button>

      <button id="navProxy" class="nav-item" onclick="switchTab('proxy-board')">
        <svg viewBox="0 0 24 24"><path d="M4 14h4v-4H4v4zm0 5h4v-4H4v4zM4 9h4V5H4v4zm5 5h12v-4H9v4zm0 5h12v-4H9v4zM9 5v4h12V5H9z"/></svg>
        <span>الاتصالات</span>
      </button>

      <button id="navEditor" class="nav-item" onclick="switchTab('editor')">
        <svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
        <span>إنشاء</span>
      </button>

      <button id="navSettings" class="nav-item" onclick="switchTab('settings')">
        <svg viewBox="0 0 24 24"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>
        <span>الإعدادات</span>
      </button>
    </div>
  </div>

  <script>
    let isConnected = false;
    let timerInterval = null;
    let secondsElapsed = 0;
    let currentProfile = ${JSON.stringify(profiles[0])};

    function appendLog(step, msg, level = 'info') {
      const container = document.getElementById('logContent');
      const time = new Date().toTimeString().split(' ')[0] + '.' + Math.floor(Math.random() * 900 + 100);
      const row = document.createElement('div');
      row.className = 'log-entry';
      row.innerHTML = \`<span class="log-time">[\${time}]</span><span class="log-msg \${level}">\${msg}</span>\`;
      container.appendChild(row);
      container.scrollTop = container.scrollHeight;
    }

    function toggleVpn() {
      const btn = document.getElementById('connectBtn');
      const radar = document.getElementById('radarRing');
      const statusLabel = document.getElementById('statusLabel');
      const timerLabel = document.getElementById('timerLabel');

      if (!isConnected) {
        // Connecting
        btn.className = 'connect-btn connecting';
        radar.className = 'radar-ring connecting';
        statusLabel.innerText = 'CONNECTING...';

        appendLog(1, \`Starting Salah VPN tunnel for '\${currentProfile.name}'\`, 'info');
        if (currentProfile.routeMode === 'PROXY_PAYLOAD') {
          appendLog(1, \`[1/6] Connecting to proxy \${currentProfile.proxyHost}:\${currentProfile.proxyPort}\`, 'step');
          setTimeout(() => {
            appendLog(2, \`[2/6] Payload sent (84 bytes)\`, 'step');
          }, 400);
          setTimeout(() => {
            appendLog(3, \`[3/6] Proxy response: HTTP/1.1 200 Connection established (48ms)\`, 'step');
          }, 800);
          setTimeout(() => {
            appendLog(4, \`[4/6] TLS handshake OK (SNI: \${currentProfile.sni || currentProfile.server})\`, 'step');
          }, 1100);
          setTimeout(() => {
            appendLog(5, \`[5/6] WebSocket upgraded (Host: \${currentProfile.headerHost || currentProfile.server}, path: \${currentProfile.path})\`, 'step');
          }, 1400);
          setTimeout(() => {
            appendLog(6, \`[6/6] \${currentProfile.protocol} connected successfully!\`, 'success');
            setConnectedState(true);
          }, 1700);
        } else {
          appendLog(1, \`[1/6] Connecting directly to target \${currentProfile.server}:\${currentProfile.port}\`, 'step');
          setTimeout(() => {
            appendLog(4, \`[4/6] TLS handshake OK\`, 'step');
            appendLog(6, \`[6/6] Direct tunnel active\`, 'success');
            setConnectedState(true);
          }, 900);
        }
      } else {
        // Disconnecting
        setConnectedState(false);
        appendLog(0, 'Salah VPN disconnected. Internet restored to normal state.', 'info');
      }
    }

    function setConnectedState(state) {
      isConnected = state;
      const btn = document.getElementById('connectBtn');
      const radar = document.getElementById('radarRing');
      const statusLabel = document.getElementById('statusLabel');
      const timerLabel = document.getElementById('timerLabel');
      const edBtn = document.getElementById('edConnectBtn');

      if (state) {
        btn.className = 'connect-btn connected';
        radar.className = 'radar-ring connected';
        statusLabel.innerText = 'CONNECTED';
        timerLabel.style.display = 'block';
        edBtn.innerText = 'DISCONNECT VPN';
        edBtn.className = 'primary-btn connected';

        secondsElapsed = 0;
        clearInterval(timerInterval);
        timerInterval = setInterval(() => {
          secondsElapsed++;
          const mins = String(Math.floor(secondsElapsed / 60)).padStart(2, '0');
          const secs = String(secondsElapsed % 60).padStart(2, '0');
          timerLabel.innerText = \`\${mins}:\${secs}\`;

          // Random speed simulation
          const downSpeed = (Math.random() * 4.5 + 1.2).toFixed(1);
          const upSpeed = (Math.random() * 1.8 + 0.4).toFixed(1);
          document.getElementById('downSpeed').innerText = \`\${downSpeed} MB/s\`;
          document.getElementById('upSpeed').innerText = \`\${upSpeed} MB/s\`;
          document.getElementById('downTotal').innerText = \`Total: \${(secondsElapsed * 2.3).toFixed(1)} MB\`;
          document.getElementById('upTotal').innerText = \`Total: \${(secondsElapsed * 0.7).toFixed(1)} MB\`;
        }, 1000);
      } else {
        btn.className = 'connect-btn';
        radar.className = 'radar-ring';
        statusLabel.innerText = 'TAP TO CONNECT';
        timerLabel.style.display = 'none';
        edBtn.innerText = 'CONNECT NOW';
        edBtn.className = 'primary-btn';
        clearInterval(timerInterval);
        document.getElementById('downSpeed').innerText = '0 KB/s';
        document.getElementById('upSpeed').innerText = '0 KB/s';
      }
    }

    function switchTab(tabId) {
      document.querySelectorAll('.tab-view').forEach(el => el.classList.remove('active'));
      document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));

      document.getElementById('tab-' + tabId).classList.add('active');
      if (tabId === 'home') document.getElementById('navHome').classList.add('active');
      if (tabId === 'proxy-board') {
        document.getElementById('navProxy').classList.add('active');
        loadProfilesList();
      }
      if (tabId === 'editor') document.getElementById('navEditor').classList.add('active');
      if (tabId === 'settings') document.getElementById('navSettings').classList.add('active');
    }

    function loadProfilesList() {
      fetch('/api/profiles')
        .then(r => r.json())
        .then(data => {
          const list = document.getElementById('profilesList');
          list.innerHTML = '';
          data.forEach(p => {
            const card = document.createElement('div');
            card.className = 'server-card';
            card.style.borderColor = p.id === currentProfile.id ? 'var(--sky-primary)' : 'var(--navy-border)';
            card.onclick = () => {
              currentProfile = p;
              updateActiveDisplay();
              switchTab('home');
            };

            const pingText = p.latencyMs ? \`\${p.latencyMs}ms\` : 'Ping';
            const pingClass = p.latencyMs ? (p.latencyMs < 150 ? 'green' : (p.latencyMs < 350 ? 'yellow' : 'red')) : '';

            card.innerHTML = \`
              <div class="server-card-top">
                <div>
                  <div class="server-title">\${p.name}</div>
                  <div class="server-summary">\${p.protocol} · \${p.transport} · \${p.routeMode}</div>
                </div>
                <div class="ping-pill \${pingClass}" onclick="event.stopPropagation(); testSinglePing('\${p.id}')">
                  <span>⚡</span><span>\${pingText}</span>
                </div>
              </div>
              <div style="margin-top:8px; font-size:11px; color:var(--text-tertiary); direction:ltr; text-align:left;">
                Target: \${p.server}:\${p.port} \${p.proxyHost ? '| Proxy: ' + p.proxyHost + ':' + p.proxyPort : ''}
              </div>
            \`;
            list.appendChild(card);
          });
        });
    }

    function updateActiveDisplay() {
      document.getElementById('activeServerName').innerText = currentProfile.name;
      document.getElementById('activeServerSummary').innerText = \`\${currentProfile.protocol} · \${currentProfile.transport} · \${currentProfile.routeMode}\`;
      document.getElementById('activeServerTarget').innerText = \`\${currentProfile.server}:\${currentProfile.port}\`;
      document.getElementById('activeServerProxy').innerText = currentProfile.proxyHost ? \`\${currentProfile.proxyHost}:\${currentProfile.proxyPort}\` : 'None (Direct)';
    }

    function testActivePing() {
      const pingText = document.getElementById('pingText');
      pingText.innerText = 'Testing...';
      fetch('/api/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(currentProfile)
      }).then(r => r.json()).then(res => {
        pingText.innerText = res.latencyMs + 'ms';
        const pill = document.getElementById('activeServerPing');
        pill.className = 'ping-pill ' + (res.latencyMs < 150 ? 'green' : (res.latencyMs < 350 ? 'yellow' : 'red'));
        if (res.logs) {
          res.logs.forEach(l => appendLog(l.step, l.message, l.level));
        }
      }).catch(() => {
        pingText.innerText = 'Failed';
      });
    }

    function testEditorConnection() {
      const p = getEditorData();
      appendLog(1, \`Testing connection to \${p.name}...\`, 'info');
      fetch('/api/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(p)
      }).then(r => r.json()).then(res => {
        if (res.logs) {
          res.logs.forEach(l => appendLog(l.step, l.message, l.level));
        }
        alert(res.success ? \`Connection Test Succeeded! Latency: \${res.latencyMs}ms (\${res.statusMessage})\` : \`Test Failed: \${res.statusMessage}\`);
      });
    }

    function getEditorData() {
      const targetParts = document.getElementById('edTarget').value.split(':');
      const proxyParts = document.getElementById('edProxy').value.split(':');
      return {
        id: 'user-' + Date.now(),
        name: document.getElementById('edName').value,
        protocol: document.getElementById('edProto').innerText,
        server: targetParts[0] || '127.0.0.1',
        port: parseInt(targetParts[1] || '443', 10),
        authKey: document.getElementById('edAuth').value,
        path: document.getElementById('edPath').value,
        sni: document.getElementById('edSni').value,
        headerHost: document.getElementById('edHost').value,
        transport: document.getElementById('edTrans').innerText,
        security: 'TLS',
        routeMode: document.getElementById('edRoute').innerText === 'Proxy -> Target' ? 'PROXY_PAYLOAD' : 'DIRECT',
        proxyHost: proxyParts[0] || '',
        proxyPort: parseInt(proxyParts[1] || '8080', 10),
        payload: document.getElementById('edPayload').value
      };
    }

    function saveEditorProfile() {
      const p = getEditorData();
      fetch('/api/profiles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(p)
      }).then(() => {
        currentProfile = p;
        updateActiveDisplay();
        alert('تم حفظ الاتصال بنجاح في Salah VPN');
        switchTab('home');
      });
    }

    function saveAndConnect() {
      saveEditorProfile();
      setTimeout(() => {
        toggleVpn();
      }, 300);
    }

    function insertPayloadVar(val) {
      const area = document.getElementById('edPayload');
      area.value += val;
    }

    function cycleProtocol() {
      const protos = ['VLESS', 'VMess', 'Trojan', 'Shadowsocks', 'Hysteria2'];
      const cur = document.getElementById('edProto').innerText;
      const next = protos[(protos.indexOf(cur) + 1) % protos.length];
      document.getElementById('edProto').innerText = next;
      document.getElementById('edAuthLabel').innerText = (next === 'VLESS' || next === 'VMess') ? '2. uuid' : '2. password';
      if (next === 'Hysteria2') {
        document.getElementById('proxyFields').style.display = 'none';
        document.getElementById('edRoute').innerText = 'Direct';
      } else {
        document.getElementById('proxyFields').style.display = 'block';
      }
    }

    function cycleTransport() {
      const trans = ['WebSocket', 'TCP', 'gRPC', 'HTTPUpgrade'];
      const cur = document.getElementById('edTrans').innerText;
      document.getElementById('edTrans').innerText = trans[(trans.indexOf(cur) + 1) % trans.length];
    }

    function cycleRoute() {
      const cur = document.getElementById('edRoute').innerText;
      const next = cur === 'Direct' ? 'Proxy -> Target' : 'Direct';
      document.getElementById('edRoute').innerText = next;
      document.getElementById('proxyFields').style.display = next === 'Direct' ? 'none' : 'block';
    }

    function copyLogs() {
      const text = document.getElementById('logContent').innerText;
      navigator.clipboard.writeText(text);
      alert('Logs copied to clipboard');
    }

    function clearLogs() {
      document.getElementById('logContent').innerHTML = \`
        <div class="log-entry"><span class="log-time">[Init]</span><span class="log-msg info">Salah VPN v1.0 [Build 2026.10] - مطورين النت في العراق</span></div>
      \`;
    }
  </script>
</body>
</html>`;
}

// Server router
const server = http.createServer((req, res) => {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  const parsedUrl = new URL(req.url, `http://${req.headers.host}`);

  if (parsedUrl.pathname === '/' || parsedUrl.pathname === '/index.html') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(getHtmlClient());
    return;
  }

  if (parsedUrl.pathname === '/api/profiles' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(profiles));
    return;
  }

  if (parsedUrl.pathname === '/api/profiles' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const newProf = JSON.parse(body);
        const idx = profiles.findIndex(p => p.id === newProf.id);
        if (idx >= 0) {
          profiles[idx] = newProf;
        } else {
          profiles.unshift(newProf);
        }
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, profile: newProf }));
      } catch (err) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
      }
    });
    return;
  }

  if (parsedUrl.pathname === '/api/test' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const prof = JSON.parse(body);
        testConnection(prof, result => {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify(result));
        });
      } catch (err) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
      }
    });
    return;
  }

  if (parsedUrl.pathname === '/api/singbox' && req.method === 'GET') {
    const prof = profiles.find(p => p.id === activeProfileId) || profiles[0];
    const config = generateSingBoxConfig(prof);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(config, null, 2));
    return;
  }

  res.writeHead(404);
  res.end('Not found');
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Salah VPN server listening on port ${PORT} (http://localhost:${PORT})`);
});
